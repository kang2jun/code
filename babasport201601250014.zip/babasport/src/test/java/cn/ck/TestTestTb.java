package cn.ck;

import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;

import cn.ck.common.junit.SpringJunitTest;
import cn.ck.core.bean.TestTb;
import cn.ck.core.service.TestTbService;


public class TestTestTb extends SpringJunitTest{
	
	@Autowired
	private TestTbService testTbService;
	
	@Test
	public void testAdd() throws Exception {
		/*ApplicationContext c = new ClassPathXmlApplicationContext("application-context.xml");
		c.getBean(arg0)*/
		TestTb testTb = new TestTb();
		testTb.setName("ck");
		testTbService.addTestTb(testTb);
	}
}
