package cn.ck;

import java.util.List;

import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;

import cn.ck.common.junit.SpringJunitTest;
import cn.ck.core.bean.product.Brand;
import cn.ck.core.query.product.BrandQuery;
import cn.ck.core.service.product.BrandService;

/**
 * 测试
 * @author lx
 *
 */

public class TestBrand extends SpringJunitTest{

	@Autowired
	private BrandService brandService;
	@Test
	public void testGet() throws Exception {
		BrandQuery  brandQuery = new BrandQuery();
		
		//brandQuery.setFields("id");
		brandQuery.setNameLike(true);
		brandQuery.setName("金");
		brandQuery.orderbyId(false);
		
		/*brandQuery.setPageNo(2);
		brandQuery.setPageSize(2);*/
		
		List<Brand> brands = brandService.getBrandList(brandQuery);
		
		for (Brand b : brands) {
			System.out.println(b);
		}
	}
}
