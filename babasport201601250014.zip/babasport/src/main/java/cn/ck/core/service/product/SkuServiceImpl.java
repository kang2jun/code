package cn.ck.core.service.product;

import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import cn.ck.core.bean.product.Sku;
import cn.ck.core.dao.product.SkuDao;
import cn.ck.core.query.product.SkuQuery;
import cn.itcast.common.page.Pagination;
/**
 * 最小销售单元事务层
 * @author lixu
 * @Date [2014-3-27 下午03:31:57]
 */
@Service
@Transactional
public class SkuServiceImpl implements SkuService {

	@Resource
	SkuDao skuDao;
	
	@Resource
	ProductService productService;

	/**
	 * 插入数据库
	 * 
	 * @return
	 */
	public Integer addSku(Sku sku) {
		return skuDao.addSku(sku);
	}

	/**
	 * 根据主键查找
	 */
	@Transactional(readOnly = true)
	public Sku getSkuByKey(Integer id) {
		Sku sku = skuDao.getSkuByKey(id);
		sku.setProduct(productService.getProductByKey(sku.getProductId()));
		sku.setColor(colorService.getColorByKey(sku.getColorId()));
		return sku;
	}
	
	@Transactional(readOnly = true)
	public List<Sku> getSkusByKeys(List<Integer> idList) {
		return skuDao.getSkusByKeys(idList);
	}

	/**
	 * 根据主键删除
	 * 
	 * @return
	 */
	public Integer deleteByKey(Integer id) {
		return skuDao.deleteByKey(id);
	}

	public Integer deleteByKeys(List<Integer> idList) {
		return skuDao.deleteByKeys(idList);
	}

	/**
	 * 根据主键更新
	 * 
	 * @return
	 */
	public Integer updateSkuByKey(Sku sku) {
		return skuDao.updateSkuByKey(sku);
	}
	
	@Transactional(readOnly = true)
	public Pagination getSkuListWithPage(SkuQuery skuQuery) {
		Pagination p = new Pagination(skuQuery.getPageNo(),skuQuery.getPageSize(),skuDao.getSkuListCount(skuQuery));
		p.setList(skuDao.getSkuListWithPage(skuQuery));
		return p;
	}
	
	@Resource
	private ColorService colorService;//sku的service层中只有调用sku的dao，而其他对象，如color，可以调用其dao也可以调用其service，区别在于提交事务的次数不同
	
	@Transactional(readOnly = true)
	public List<Sku> getSkuList(SkuQuery skuQuery) {
		List<Sku> skus = skuDao.getSkuList(skuQuery);
		for(Sku sku : skus){//查出颜色，给前台显示，不然你给个colorId谁知道这是什么是吧
			sku.setColor(colorService.getColorByKey(sku.getColorId()));
		}
		return skus;
	}

	public List<Sku> getStock(Integer productId) {
		List<Sku> skus = skuDao.getStock(productId);
		for(Sku sku : skus){//查出颜色，给前台显示，不然你给个colorId谁知道这是什么是吧
			sku.setColor(colorService.getColorByKey(sku.getColorId()));
		}
		return skus;
	}

}
