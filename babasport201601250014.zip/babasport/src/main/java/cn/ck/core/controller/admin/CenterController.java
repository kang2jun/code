package cn.ck.core.controller.admin;

import java.util.Date;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

/**
 * 后台管理的
 * @author	ck
 * @date	2016年1月8日下午11:43:39
 */
@Controller
@RequestMapping(value="/control")
public class CenterController {
	
	@RequestMapping(value="/test/springmvc.do")
	public String test(String name,Date birthday){

		System.out.println();
		return "";
	}
	
	/*	@InitBinder
	public void initBinder(WebDataBinder binder, WebRequest request) {
		//转换日期格式
		DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		binder.registerCustomEditor(Date.class, new CustomDateEditor(dateFormat, true));
	}*/
	
	@RequestMapping(value="/index.do")
	public String index(){

		return "index";
	}
	
	@RequestMapping(value="/top.do")
	public String top(){

		return "top";
	}
	
	@RequestMapping(value="/main.do")
	public String main(){

		return "main";
	}
	
	@RequestMapping(value="/left.do")
	public String left(){

		return "left";
	}
	
	@RequestMapping(value="/right.do")
	public String right(){

		return "right";
	}
	

}
