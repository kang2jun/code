package cn.ck.core.web;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.servlet.HandlerInterceptor;
import org.springframework.web.servlet.ModelAndView;

import cn.ck.common.web.session.SessionProvider;
import cn.ck.core.bean.user.Buyer;

public class SpringmvcInterceptor implements HandlerInterceptor{

	@Autowired
	private SessionProvider sessionProvider;
	//常量
	private static final String INTERCEPTOR_URL = "/buyer/";
	
	//方法前
	public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler)
			throws Exception {
		Buyer buyer = (Buyer) sessionProvider.getAttribute(request, Cons.BUYER_SESSION);
		boolean flag = false;
		if (null != buyer) {
			flag = true;
		}
		request.setAttribute("isLogin", flag);
		//是否拦截   http://localhost:8080/buyer/index.shtml
		//  /buyer/index.shtml
		String requestURI = request.getRequestURI();
		if (requestURI.startsWith(INTERCEPTOR_URL)) {
			if (null == buyer) {
				String url = request.getParameter("returnUrl");
				if (!StringUtils.isNotBlank(url)) {
					url = request.getRequestURL().toString();
				}
				response.sendRedirect("/shopping/login.shtml?returnUrl="+url);
				return false;
			}
		}
		return true;
	}

	//方法后
	public void postHandle(HttpServletRequest request, HttpServletResponse response, Object handler,
			ModelAndView modelAndView) throws Exception {
	}
	
	//页面渲染后
	public void afterCompletion(HttpServletRequest request, HttpServletResponse response, Object handler, Exception ex)
			throws Exception {
	}

}
