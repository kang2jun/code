package cn.ck.core.controller;

import java.util.ArrayList;
import java.util.Date;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;

import cn.ck.core.bean.product.Brand;
import cn.ck.core.bean.product.Color;
import cn.ck.core.bean.product.Feature;
import cn.ck.core.bean.product.Product;
import cn.ck.core.bean.product.Sku;
import cn.ck.core.bean.product.Type;
import cn.ck.core.query.product.BrandQuery;
import cn.ck.core.query.product.ColorQuery;
import cn.ck.core.query.product.FeatureQuery;
import cn.ck.core.query.product.ProductQuery;
import cn.ck.core.query.product.SkuQuery;
import cn.ck.core.query.product.TypeQuery;
import cn.ck.core.service.product.BrandService;
import cn.ck.core.service.product.ColorService;
import cn.ck.core.service.product.FeatureService;
import cn.ck.core.service.product.ProductService;
import cn.ck.core.service.product.SkuService;
import cn.ck.core.service.product.TypeService;
import cn.itcast.common.page.Pagination;

/**
 * 后台管理的
 * @author	ck
 * @date	2016年1月8日下午11:43:39
 */
@Controller
public class FrontProductController {
	
	@RequestMapping(value="/test/springmvc.do")
	public String test(String name,Date birthday){

		System.out.println();
		return "";
	}
	
	/*	@InitBinder
	public void initBinder(WebDataBinder binder, WebRequest request) {
		//转换日期格式
		DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		binder.registerCustomEditor(Date.class, new CustomDateEditor(dateFormat, true));
	}*/
	
	@Autowired
	private BrandService brandService;
	
	@Autowired
	private ProductService productService;
	
	@Autowired
	private FeatureService featureService;
	
	@Autowired
	private TypeService typeService;
	
	@RequestMapping(value="/product/display/list.shtml")
	public String list(Integer pageNo,Integer brandId,String brandName,Integer typeId,String typeName,ModelMap model){
		//加载商品属性
		FeatureQuery featureQuery = new FeatureQuery();
		
		List<Feature> features = featureService.getFeatureList(featureQuery);
		//显示在页面
		model.addAttribute("features", features);
		
		//分页参数
		StringBuilder params = new StringBuilder();
		
		//设置页号
		ProductQuery productQuery = new ProductQuery();
		productQuery.setPageNo(Pagination.cpn(pageNo));
		//设置每页数
		productQuery.setPageSize(Product.FRONT_PAGE_SIZE);
		//设置Id倒排
		productQuery.orderbyId(false);
		
		boolean showChecked = false;//是否显示已筛选的条件
		
		Map<String, String> query = new LinkedHashMap<String, String>();
		
		if(null != brandId){//筛选了品牌，传递过来了brandId和brandName，不用去访问数据库，将传递过来的筛选条件再次返回，保持已选条件的状态
			productQuery.setBrandId(brandId);//指定了某一品牌的产品查询

			showChecked =true;//表示已经选了品牌了，所筛选的条件要显示，而品牌的list表则不显示
			query.put("品牌", brandName);//显示已筛选条件的
			
			model.addAttribute("brandId", brandId);//传给a标签的，以指定下次请求list带brandId参数
			model.addAttribute("brandName", brandName);//传给a标签的，以指定下次请求list带brandName参数，和brandId一起设置和传递的，正常操作不可能为空，除非用户恶意操作
			
			params.append("&").append("brandId=").append(brandId).append("&brandName=").append(brandName);//给分页准备的，每页的按钮都带了brand的条件
		}else{//brand为null，代表没有对品牌进行筛选，返回的是brands
			//加载商品品牌
			//品牌条件对象
			BrandQuery brandQuery = new BrandQuery();
			//设置指定字段
			brandQuery.setFields("id,name");
			//设置可见
			brandQuery.setIsDisplay(1);
			//加载品牌
			List<Brand> brands = brandService.getBrandList(brandQuery);
			//显示在页面
			model.addAttribute("brands", brands);
		}
		//一下逻辑和上面brand的一致，我就不注释了
		if(null != typeId){
			productQuery.setTypeId(typeId);
			showChecked = true;
			query.put("类型", typeName);//显示已筛选条件的
			
			model.addAttribute("typeId", typeId);//传给a标签的，以指定下次请求list带brandId参数
			model.addAttribute("typeName", typeName);//传给a标签的，以指定下次请求list带brandName参数，和brandId一起设置和传递的，正常操作不可能为空，除非用户恶意操作
			
			params.append("&").append("typeId=").append(typeId).append("&typeName=").append(typeName);
		}else{//加载商品类型
			TypeQuery typeQuery = new TypeQuery();
			typeQuery.setFields("id,name");
			typeQuery.setIsDisplay(1);
			typeQuery.setParentId(0);
			List<Type> types = typeService.getTypeList(typeQuery);
			model.addAttribute("types", types);
		}
		
		Pagination pagination = productService.getProductListWithPage(productQuery);
		//分页页面展示    //String params = "brandId=1&name=2014瑜伽服套装新款&pageNo=1";
		pagination.pageView("/product/display/list.shtml?", params.toString());
		
		model.addAttribute("pagination", pagination);
		model.addAttribute("query",query);
		model.addAttribute("flag", showChecked);
		return "product/product";
	}
	
	@Autowired
	private SkuService skuService;
	
	@RequestMapping(value="/product/detail.shtml")
	public String detail(Integer id,ModelMap model){
		Product product = productService.getProductByKey(id);
		
		if(null == id){
			return "msg";
		}
		List<Sku> skus = skuService.getStock(id);
		List<Color> colors = new ArrayList<Color>();
		for(Sku sku : skus){
			if(!colors.contains(sku.getColor())){
				colors.add(sku.getColor());
			}
		}
		model.addAttribute("skus", skus);
		model.addAttribute("colors", colors);
		model.addAttribute("product", product);
		return "product/productDetail";
	}
	

}
