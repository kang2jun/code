package cn.ck.core.service;

import cn.ck.core.bean.TestTb;

public interface TestTbService {
	
	public void addTestTb(TestTb testTb);
}
