package cn.ck.core.controller.admin;

import java.util.List;

import javax.servlet.http.HttpServletResponse;

import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;

import cn.ck.common.web.ResponseUtils;
import cn.ck.core.bean.product.Sku;
import cn.ck.core.query.product.SkuQuery;
import cn.ck.core.service.product.SkuService;
import cn.itcast.common.page.Pagination;

/**
 * sku：最小销售单元
 * @author	ck
 * @date	2016年1月8日下午11:43:39
 */
@Controller
@RequestMapping(value="/sku")
public class SkuController {
	
	@Autowired
 	private SkuService skuService;
	
	@RequestMapping(value="/list.do")
	public String list(Integer productId,String pno,ModelMap model){
		SkuQuery skuQuery = new SkuQuery();
		skuQuery.setProductId(productId);
		List<Sku> skus = skuService.getSkuList(skuQuery);
		
		model.addAttribute("pno", pno);
		model.addAttribute("skus",skus);
		return "sku/list";
	}
	
	@RequestMapping(value="/update.do")
	public void update(Sku sku,HttpServletResponse response){
		skuService.updateSkuByKey(sku);
	
		JSONObject jObject = new JSONObject();
		jObject.put("message", "保存成功");
		ResponseUtils.renderJson(response, jObject.toString());
	}

}
