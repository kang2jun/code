package cn.ck.core.dao;

import cn.ck.core.bean.TestTb;

public interface TestTbDao {
	public void addTestTb(TestTb testTb);
}
