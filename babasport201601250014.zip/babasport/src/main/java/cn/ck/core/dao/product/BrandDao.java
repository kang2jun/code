package cn.ck.core.dao.product;

import java.util.List;

import cn.ck.core.bean.product.Brand;
import cn.ck.core.query.product.BrandQuery;

/**
 * brand's dao
 * @author	ck
 * @date	2016年1月9日下午9:12:30
 */
public interface BrandDao {
	public List<Brand> getBrandListWithPage(Brand brand);
	
	public int getBrandCount(Brand brand);

	public void add(Brand brand);

	public void deleteById(Integer id);

	public void deleteByIds(Integer[] ids);

	public void update(Brand brand);

	public Brand getBrandByKey(Integer id);
	
	//查询集合
	public List<Brand> getBrandList(BrandQuery brandQuery);
	
}
