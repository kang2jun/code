package cn.ck.core.service.staticpage;

import java.util.Map;

/**
 * 静态化页面生成器
 * @author	ck
 * @date	2016年1月19日下午11:15:59
 */
public interface StaticPageService {
	
	/**
	 * 根据不同的product的id生成对应的商品详情页
	 * */
	public void productIndex(Map<String, Object> root, Integer id);

}
