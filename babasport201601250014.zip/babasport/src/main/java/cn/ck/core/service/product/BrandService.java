package cn.ck.core.service.product;

import java.util.List;

import cn.ck.core.bean.product.Brand;
import cn.ck.core.query.product.BrandQuery;
import cn.itcast.common.page.Pagination;

public interface BrandService {
	public Pagination getBrandListWithPage(Brand brand);

	public void add(Brand brand);

	public void deleteById(Integer id);
	
	public void deleteByIds(Integer[] ids);
	
	public void update(Brand brand);

	public Brand getBrandByKey(Integer id);
	//查询集合
	public List<Brand> getBrandList(BrandQuery brandQuery);
}
