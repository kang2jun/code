package cn.ck.core.controller.admin;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;

import cn.ck.core.bean.product.Brand;
import cn.ck.core.service.product.BrandService;
import cn.itcast.common.page.Pagination;

/**
 * 品牌管理
 * @author	ck
 * @date	2016年1月9日下午9:36:39
 */
@Controller
@RequestMapping(value="/brand")
public class BrandController {
	
	@Autowired
	private BrandService brandService;
	
	//品牌列表
	@RequestMapping(value="/list.do")
	public String list(String name,Integer isDisplay,Integer pageNo,ModelMap model){
		
		StringBuilder params = new StringBuilder();
		Brand brand = new Brand();
		if(StringUtils.isNotBlank(name)){
			brand.setName(name);
			params.append("name=").append(name);
		}
		if(null != isDisplay){
			brand.setIsDisplay(isDisplay);
			params.append("&").append("isDisplay=").append(isDisplay);
		}else{
			brand.setIsDisplay(1);
			params.append("&").append("isDisplay=").append(1);
		}
		brand.setPageNo(Pagination.cpn(pageNo));
		
		brand.setPageSize(5);
		
		Pagination pagination = brandService.getBrandListWithPage(brand);
		
		String url = "/brand/list.do";
		pagination.pageView(url, params.toString());
		
		model.addAttribute("pagination", pagination);
		model.addAttribute("isDisplay", isDisplay);
		model.addAttribute("name", name);
		
		return "brand/list";
	}
	
	//to brand's add.jsp
	@RequestMapping(value="/toAdd.do")
	public String toAdd(){
		return "brand/add";
	}
	
	//brand's add controller
	@RequestMapping(value ="/add.do")
	public String add(Brand brand){
		brandService.add(brand);
		return "redirect:/brand/list.do";
	}
	
	@RequestMapping(value="/delete.do")
	public String delete(Integer id,String name,Integer isDisplay,ModelMap model){
		brandService.deleteById(id);
		
		if(StringUtils.isNotBlank(name))
		model.addAttribute("name", name);
		
		if(null != isDisplay)
		model.addAttribute("isDisplay",isDisplay);
		
		return "redirect:/brand/list.do";
	}
	
	@RequestMapping(value="/deletes.do")
	public String deletes(Integer[] ids,String name,Integer isDisplay,ModelMap model){
		brandService.deleteByIds(ids);
		
		if(StringUtils.isNotBlank(name))
		model.addAttribute("name", name);
		
		if(null != isDisplay)
		model.addAttribute("isDisplay",isDisplay);
		
		return "redirect:/brand/list.do";
	}
	
	@RequestMapping(value="/toEdit")
	public String toEdit(Integer id,String name,Integer isDisplay,ModelMap model){
		
		Brand brand = brandService.getBrandByKey(id);
		model.addAttribute("brand", brand);
		model.addAttribute("name",name);
		model.addAttribute("isDisplay", isDisplay);
		
		return "brand/edit";
	}
	
	@RequestMapping(value="/edit")
	public String edit(Brand brand){
		brandService.update(brand);
		return "redirect:/brand/list.do";
	}
	
}
