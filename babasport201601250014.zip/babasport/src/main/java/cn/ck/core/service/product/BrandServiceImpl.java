package cn.ck.core.service.product;

import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import cn.ck.core.bean.product.Brand;
import cn.ck.core.dao.product.BrandDao;
import cn.ck.core.query.product.BrandQuery;
import cn.itcast.common.page.Pagination;

@Service
@Transactional
public class BrandServiceImpl implements BrandService {

	@Resource
	private BrandDao brandDao;
	
	@Transactional(readOnly=true)
	public Pagination getBrandListWithPage(Brand brand) {
		
		Pagination pagination = new Pagination(brand.getPageNo(), brand.getPageSize(), brandDao.getBrandCount(brand));
		pagination.setList(brandDao.getBrandListWithPage(brand));
		
		return pagination;
	}

	public void add(Brand brand) {
		brandDao.add(brand);
	}

	public void deleteById(Integer id) {
		brandDao.deleteById(id);
	}

	public void deleteByIds(Integer[] ids) {
		brandDao.deleteByIds(ids);
	}

	public void update(Brand brand) {
		brandDao.update(brand);
	}

	public Brand getBrandByKey(Integer id) {
		return brandDao.getBrandByKey(id);
	}

	public List<Brand> getBrandList(BrandQuery brandQuery) {
		return brandDao.getBrandList(brandQuery);
	}

}
