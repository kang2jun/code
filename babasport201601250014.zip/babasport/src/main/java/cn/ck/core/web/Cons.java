package cn.ck.core.web;

public interface Cons {
	/**
	 * 图片服务器
	 */
	public static final String IMAGE_SERVER_URL = "http://localhost:8088/image-web/";
	/**
	 * 用户Session
	 */
	public static final String BUYER_SESSION = "buyer_session";
	/**
	 * 购物车Cookie
	 */
	public static final String BUYCART_COOKIE = "buyCart_cookie";
}
