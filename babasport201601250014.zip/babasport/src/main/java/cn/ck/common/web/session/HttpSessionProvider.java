package cn.ck.common.web.session;

import java.io.Serializable;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

public class HttpSessionProvider implements SessionProvider {

	public void setAttribute(HttpServletRequest request, String name, Serializable value) {
		HttpSession session = request.getSession();//默认为true，先查询，有则返回，没有则创建
		session.setAttribute(name, value);
	}

	public Serializable getAttribute(HttpServletRequest request, String name) {
		HttpSession session = request.getSession(false);//getSession(boolean create)
		if(null != session){//不希望创建session，如果没有则为null，attribute也为null
			return (Serializable) session.getAttribute(name);
		}
		return null;
	}

	public void logout(HttpServletRequest request) {
		HttpSession session = request.getSession();
		if (null != session) {
			session.invalidate();//清除session对象
		}
		//Cookie JESSIONID
	}

	public String getSessionId(HttpServletRequest request) {
		//request.getRequestedSessionId();//Http://localhost:8080/html/sfsf.shtml?JESSIONID=ewrqwrq234123412
		return request.getSession().getId();
	}

}
