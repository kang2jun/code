package cn.ck.common.encode;

public interface Md5Pwd {

	public String  encode(String password);
}
