function doNumber(){
	var res = document.form1.sid.value;
     if(!feeCode.macth("^[0-9_]+$")){
               alert("不是数字");
               return false;
     }else{
               alert("是数字");
               return true;
     }
}