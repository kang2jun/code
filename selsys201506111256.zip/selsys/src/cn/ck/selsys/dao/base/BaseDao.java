package cn.ck.selsys.dao.base;

import java.io.Serializable;
import java.util.Collection;
import java.util.List;

import cn.ck.selsys.domain.PageBean;
import cn.ck.selsys.utils.QueryHelper;

public interface BaseDao<T> {
	
public Collection<T> getAllEntry();
	
	public T getEntryById(Serializable id);
	
	public void saveEntry(T t);
	
	public void updateEntry(T t);
	
	public void deleteEntry(Serializable id);
	
	public T findByIdAndPassword(T t,Serializable id,String password);
	
	/**
	 * 公共的查询分页信息的方法
	 * 
	 * @param pageNum
	 * @param pageSize
	 * @param hql
	 *            查询数据列表的HQL
	 * @param parameters
	 *            参数列表，与HQL中问号一一对应
	 * @return
	 */
	@Deprecated
	PageBean getPageBean(int pageNum, int pageSize, String hql, List<Object> parameters);

	/**
	 * 公共的查询分页信息的方法（最终版）
	 * 
	 * @param pageNum
	 * @param pageSize
	 * @param queryHelper
	 *            HQL语句与参数列表
	 * @return
	 */
	PageBean getPageBean(int pageNum, int pageSize, QueryHelper queryHelper);

}
