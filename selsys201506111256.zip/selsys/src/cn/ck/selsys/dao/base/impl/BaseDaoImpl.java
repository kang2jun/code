package cn.ck.selsys.dao.base.impl;

import java.io.Serializable;
import java.lang.reflect.ParameterizedType;
import java.util.Collection;
import java.util.List;

import javax.annotation.Resource;

import org.hibernate.Query;
import org.hibernate.Session;
import org.springframework.orm.hibernate3.HibernateTemplate;

import cn.ck.selsys.dao.base.BaseDao;
import cn.ck.selsys.domain.PageBean;
import cn.ck.selsys.domain.Student;
import cn.ck.selsys.domain.Teacher;
import cn.ck.selsys.utils.QueryHelper;

public class BaseDaoImpl<T> implements BaseDao<T> {
	
	private Class classt;
	
	/*	public void aa(){
			ParameterizedType type = (ParameterizedType) this.getClass().getGenericSuperclass();
		}*/
		public BaseDaoImpl(){
			/**
			 * ParameterizedType这个就是泛型
			 */
			ParameterizedType type = (ParameterizedType) this.getClass().getGenericSuperclass();
			this.classt = (Class) type.getActualTypeArguments()[0];
		}
		@Resource(name="hibernateTemplate")
		public HibernateTemplate hibernateTemplate;
		
		protected Session getSession() {
			return hibernateTemplate.getSessionFactory().getCurrentSession();
		}
		

		public void deleteEntry(Serializable id) {
			T t = this.getEntryById(id);
			this.hibernateTemplate.delete(t);
		}

		//@JSON(serialize=false)
		public Collection<T> getAllEntry() {
			return this.hibernateTemplate.find("from "+this.classt.getName());
		}

		public T getEntryById(Serializable id) {
			return (T) this.hibernateTemplate.get(this.classt, id);
		}

		public void saveEntry(T t) {
			this.hibernateTemplate.save(t);
		}

		public void updateEntry(T t) {
			this.hibernateTemplate.update(t);
		}

		public T findByIdAndPassword(T t, Serializable id, String password) {
			String sql = "";
			if(t instanceof Student){
				sql = "from Student where sid=? and password=?";
			}else if(t instanceof Teacher){
				sql = "from Teacher where tid=? and password=?";
			}else{
				sql = "from Man where mid=? and password=?";
			}
			List<T> userList = this.hibernateTemplate.find(sql,new Object[]{id,password});
			if(userList.size()!=0){
				return (T) userList.get(0);
			}else{
				return null;
			}
		}
		
		// 公共的查询分页信息的方法
		@Deprecated
		public PageBean getPageBean(int pageNum, int pageSize, String hql, List<Object> parameters) {
			System.out.println("-------> DaoSupportImpl.getPageBean()");

			// 查询本页的数据列表
			Query listQuery = getSession().createQuery(hql); // 创建查询对象
			if (parameters != null) { // 设置参数
				for (int i = 0; i < parameters.size(); i++) {
					listQuery.setParameter(i, parameters.get(i));
				}
			}
			listQuery.setFirstResult((pageNum - 1) * pageSize);
			listQuery.setMaxResults(pageSize);
			List list = listQuery.list(); // 执行查询

			// 查询总记录数量
			Query countQuery = getSession().createQuery("SELECT COUNT(*) " + hql);
			if (parameters != null) { // 设置参数
				for (int i = 0; i < parameters.size(); i++) {
					countQuery.setParameter(i, parameters.get(i));
				}
			}
			Long count = (Long) countQuery.uniqueResult(); // 执行查询

			return new PageBean(pageNum, pageSize, count.intValue(), list);
		}

		// 公共的查询分页信息的方法（最终版）
		public PageBean getPageBean(int pageNum, int pageSize, QueryHelper queryHelper) {
			System.out.println("-------> DaoSupportImpl.getPageBean( int pageNum, int pageSize, QueryHelper queryHelper )");

			// 参数列表
			List<Object> parameters = queryHelper.getParameters();
			List<Long> longs = queryHelper.getInparameter();

			// 查询本页的数据列表
			Query listQuery = getSession().createQuery(queryHelper.getListQueryHql()); // 创建查询对象
			if (parameters != null) { // 设置参数
				for (int i = 0; i < parameters.size(); i++) {
					listQuery.setParameter(i, parameters.get(i));
				}
			}
			if(queryHelper.getHavain()){
				listQuery.setParameterList("alist", longs);
			}
			listQuery.setFirstResult((pageNum - 1) * pageSize);
			listQuery.setMaxResults(pageSize);
			List list = listQuery.list(); // 执行查询

			// 查询总记录数量
			Query countQuery = getSession().createQuery(queryHelper.getCountQueryHql());
			if (parameters != null) { // 设置参数
				for (int i = 0; i < parameters.size(); i++) {
					countQuery.setParameter(i, parameters.get(i));
				}
			}
			if(queryHelper.getHavain()){
				countQuery.setParameterList("alist", longs);
			}
			Long count = (Long) countQuery.uniqueResult(); // 执行查询

			return new PageBean(pageNum, pageSize, count.intValue(), list);
		}
}
