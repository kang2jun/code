package cn.ck.selsys.dao;

import java.io.Serializable;
import java.util.Collection;

import cn.ck.selsys.dao.base.BaseDao;
import cn.ck.selsys.domain.Sub;

public interface SubDao<T> extends BaseDao<T>{
	public Collection<Sub> getSubsByDid(Serializable id);
}
