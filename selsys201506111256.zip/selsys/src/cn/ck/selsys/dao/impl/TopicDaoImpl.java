package cn.ck.selsys.dao.impl;

import java.util.Collection;

import org.springframework.stereotype.Repository;

import cn.ck.selsys.dao.TopicDao;
import cn.ck.selsys.dao.base.impl.BaseDaoImpl;
import cn.ck.selsys.domain.Topic;

@Repository("topicDao")
public class TopicDaoImpl extends BaseDaoImpl<Topic> implements TopicDao<Topic>{

	public Collection<Topic> getTopicsByTid(Long tid) {
		// TODO Auto-generated method stub
		return this.hibernateTemplate.find("from Topic t inner join fetch t.teacher r where r.tid=?",tid);
	}

	public Collection<Topic> getTopicsByDid(Long did) {
		// TODO Auto-generated method stub
		return this.hibernateTemplate.find("from Topic t where t.teacher.deparment.did=?",did);
	}
	
	

}
