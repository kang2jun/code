package cn.ck.selsys.dao.impl;

import java.util.Collection;

import org.springframework.stereotype.Repository;

import cn.ck.selsys.dao.TeacherDao;
import cn.ck.selsys.dao.base.impl.BaseDaoImpl;
import cn.ck.selsys.domain.Teacher;

@Repository("teacherDao")
public class TeacherDaoImpl extends BaseDaoImpl<Teacher> implements TeacherDao<Teacher>{

	public Collection<Teacher> getTeachersByDid(Long did) {
		return this.hibernateTemplate.find("from Teacher t where t.department.did=?",did);
	}
	

}
