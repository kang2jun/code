package cn.ck.selsys.dao.impl;

import java.io.Serializable;
import java.util.Collection;
import java.util.List;

import org.springframework.stereotype.Repository;

import cn.ck.selsys.dao.SubDao;
import cn.ck.selsys.dao.base.impl.BaseDaoImpl;
import cn.ck.selsys.domain.Sub;

@Repository("subDao")
public class SubDaoImpl extends BaseDaoImpl<Sub> implements SubDao<Sub>{

	public Collection<Sub> getSubsByDid(Serializable id) {
		// TODO Auto-generated method stub
		String sql = "from Sub s inner join fetch s.department d where d.did=?";
		List<Sub> list = hibernateTemplate.find(sql, new Object[]{id});
		return list;
	}

}
