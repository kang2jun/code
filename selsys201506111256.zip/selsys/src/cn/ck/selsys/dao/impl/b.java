package cn.ck.selsys.dao.impl;

public class b {

}
