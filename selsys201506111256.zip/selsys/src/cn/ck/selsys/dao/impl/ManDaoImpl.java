package cn.ck.selsys.dao.impl;

import org.springframework.stereotype.Repository;

import cn.ck.selsys.dao.ManDao;
import cn.ck.selsys.dao.base.BaseDao;
import cn.ck.selsys.dao.base.impl.BaseDaoImpl;
import cn.ck.selsys.domain.Man;

@Repository("manDao")
public class ManDaoImpl extends BaseDaoImpl<Man> implements ManDao<Man>{

}
