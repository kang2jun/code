package cn.ck.selsys.dao.impl;

import java.util.Collection;
import java.util.List;

import org.hibernate.Query;
import org.springframework.stereotype.Repository;

import cn.ck.selsys.dao.StudentDao;
import cn.ck.selsys.dao.base.impl.BaseDaoImpl;
import cn.ck.selsys.domain.Student;

@Repository("studentDao")
public class StudentDaoImpl extends BaseDaoImpl<Student> implements StudentDao<Student>{

	public Collection<Student> getStudentsBySubIds(List<Long> ids) {
		String sql = "from Student s inner join fetch s.sub su where su.subid in (:alist)";
		Query query = getSession().createQuery(sql);
		query.setParameterList("alist", ids);
		
		return query.list();
	}

}
