package cn.ck.selsys.dao.impl;

import org.springframework.stereotype.Repository;

import cn.ck.selsys.dao.DepartmentDao;
import cn.ck.selsys.dao.base.BaseDao;
import cn.ck.selsys.dao.base.impl.BaseDaoImpl;
import cn.ck.selsys.domain.Department;

@Repository("departmentDao")
public class DepartmentDaoImpl extends BaseDaoImpl<Department> implements DepartmentDao<Department>{

}
