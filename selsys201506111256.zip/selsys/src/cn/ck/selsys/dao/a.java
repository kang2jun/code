package cn.ck.selsys.dao;

public class a {

}
