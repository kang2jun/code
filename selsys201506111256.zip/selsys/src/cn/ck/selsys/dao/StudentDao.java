package cn.ck.selsys.dao;

import java.util.Collection;
import java.util.List;

import cn.ck.selsys.dao.base.BaseDao;
import cn.ck.selsys.domain.Student;

public interface StudentDao<T> extends BaseDao<T>{
	public Collection<Student> getStudentsBySubIds(List<Long> ids);
}
