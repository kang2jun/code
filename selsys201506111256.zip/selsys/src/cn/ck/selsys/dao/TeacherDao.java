package cn.ck.selsys.dao;

import java.util.Collection;

import cn.ck.selsys.dao.base.BaseDao;
import cn.ck.selsys.domain.Teacher;

public interface TeacherDao<T> extends BaseDao<T>{
	public Collection<Teacher> getTeachersByDid(Long did);

}
