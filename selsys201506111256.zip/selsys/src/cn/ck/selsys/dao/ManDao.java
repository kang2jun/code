package cn.ck.selsys.dao;

import cn.ck.selsys.dao.base.BaseDao;

public interface ManDao<T> extends BaseDao<T>{

}
