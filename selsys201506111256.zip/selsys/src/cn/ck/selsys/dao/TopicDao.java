package cn.ck.selsys.dao;

import java.util.Collection;

import cn.ck.selsys.dao.base.BaseDao;

public interface TopicDao<T> extends BaseDao<T>{
	
	public Collection<T> getTopicsByTid(Long tid);
	
	public Collection<T> getTopicsByDid(Long Did);

}
