package cn.ck.selsys.exception;

import com.opensymphony.xwork2.ActionContext;

public class CKException {
	public void getExceptionMessage(Throwable ex){
		ActionContext.getContext().getValueStack().push(ex.getMessage());
	}
}
