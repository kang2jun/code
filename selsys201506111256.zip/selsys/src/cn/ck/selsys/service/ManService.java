package cn.ck.selsys.service;

import java.io.Serializable;
import java.util.Collection;

import cn.ck.selsys.dao.base.BaseDao;
import cn.ck.selsys.domain.Man;

public interface ManService extends BaseDao<Man>{
	
	public void saveMan(Man Man);

	public void updateMan(Man Man);

	public void deleteManById(Serializable id,String deleteMode);

	public Collection<Man> getAllMan();

	public Man getManById(Serializable id);
	
	public Man findByLoginNameAndPassword(Man s ,Serializable sid, String password);
}
