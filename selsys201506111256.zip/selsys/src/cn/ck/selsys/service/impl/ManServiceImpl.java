package cn.ck.selsys.service.impl;

import java.io.Serializable;
import java.util.Collection;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import cn.ck.selsys.dao.ManDao;
import cn.ck.selsys.dao.base.impl.BaseDaoImpl;
import cn.ck.selsys.domain.Man;
import cn.ck.selsys.service.ManService;

@Service("manService")
public class ManServiceImpl extends BaseDaoImpl<Man> implements ManService{
	
	@Resource(name="manDao")
	private ManDao manDao;

	@Transactional(readOnly=false)
	public void deleteManById(Serializable id, String deleteMode) {
		// TODO Auto-generated method stub
		this.manDao.deleteEntry(id);
	}

	public Collection<Man> getAllMan() {
		// TODO Auto-generated method stub
		return this.manDao.getAllEntry();
	}

	public Man getManById(Serializable id) {
		// TODO Auto-generated method stub
		return (Man) this.manDao.getEntryById(id);
	}

	@Transactional(readOnly=false)
	public void saveMan(Man man) {
		// TODO Auto-generated method stub
		this.manDao.saveEntry(man);
		
	}

	@Transactional(readOnly=false)
	public void updateMan(Man man) {
		// TODO Auto-generated method stub
		this.manDao.updateEntry(man);
		
	}
	
	public Man findByLoginNameAndPassword(Man s ,Serializable sid, String password) {
		// 使用密码的MD5摘要进行对比
		/*String md5Digest = DigestUtils.md5Hex(password);
		return (Man) getSession().createQuery(//
				"FROM User u WHERE u.loginName=? AND u.password=?")//
				.setParameter(0, loginName)//
				.setParameter(1, md5Digest)//
				.uniqueResult();*/
		//ManDao.findByIdAndPassword(t, id, password)
		return (Man) manDao.findByIdAndPassword(s, sid, password);
	}

}
