package cn.ck.selsys.service.impl;

import java.io.Serializable;
import java.util.Collection;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import cn.ck.selsys.dao.TopicDao;
import cn.ck.selsys.dao.base.impl.BaseDaoImpl;
import cn.ck.selsys.domain.Topic;
import cn.ck.selsys.service.TopicService;

@Service("topicService")
public class TopicServiceImpl extends BaseDaoImpl<Topic> implements TopicService{
	@Resource(name="topicDao")
	private TopicDao topicDao;

	@Transactional(readOnly=false)
	public void deleteTopicById(Serializable id,String deleteMode) {
		// TODO Auto-generated method stub
		this.topicDao.deleteEntry(id);
	}

	//@JSON(serialize=false)
	public Collection<Topic> getAllTopic() {
		// TODO Auto-generated method stub
		//return this.TopicDao.getAllTopic();
		//int a = 1/0;
		return this.topicDao.getAllEntry();
	}

	public Topic getTopicById(Serializable id) {
		// TODO Auto-generated method stub
		return (Topic) this.topicDao.getEntryById(id);
	}

	@Transactional(readOnly=false)
	public void saveTopic(Topic Topic) {
		// TODO Auto-generated method stub
		//this.TopicDao.saveTopic(Topic);
		this.topicDao.saveEntry(Topic);
	}

	@Transactional(readOnly=false)
	public void updateTopic(Topic Topic) {
		// TODO Auto-generated method stub
		this.topicDao.updateEntry(Topic);
	}

	public Collection<Topic> getTopicsByTid(Long tid) {
		// TODO Auto-generated method stub
		return topicDao.getTopicsByTid(tid);
	}

	public Collection<Topic> getTopicsByDid(Long did) {
		// TODO Auto-generated method stub
		return this.topicDao.getTopicsByDid(did);
	}
	
}
