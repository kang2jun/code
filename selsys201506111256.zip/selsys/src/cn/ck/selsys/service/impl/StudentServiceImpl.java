package cn.ck.selsys.service.impl;

import java.io.Serializable;
import java.util.Collection;
import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import cn.ck.selsys.dao.StudentDao;
import cn.ck.selsys.dao.base.impl.BaseDaoImpl;
import cn.ck.selsys.domain.Student;
import cn.ck.selsys.service.StudentService;

@Service("studentService")
public class StudentServiceImpl extends BaseDaoImpl<Student> implements StudentService{
	
	@Resource(name="studentDao")
	private StudentDao studentDao;

	public void deleteStudentById(Serializable id, String deleteMode) {
		// TODO Auto-generated method stub
		this.studentDao.deleteEntry(id);
	}

	public Collection<Student> getAllStudent() {
		// TODO Auto-generated method stub
		return this.studentDao.getAllEntry();
	}

	public Student getStudentById(Serializable id) {
		// TODO Auto-generated method stub
		return (Student) this.studentDao.getEntryById(id);
	}

	public void saveStudent(Student student) {
		// TODO Auto-generated method stub
		this.studentDao.saveEntry(student);
		
	}

	public void updateStudent(Student student) {
		// TODO Auto-generated method stub
		this.studentDao.updateEntry(student);
		
	}
	
	public Student findByLoginNameAndPassword(Student s ,Serializable sid, String password) {
		// 使用密码的MD5摘要进行对比
		/*String md5Digest = DigestUtils.md5Hex(password);
		return (Student) getSession().createQuery(//
				"FROM User u WHERE u.loginName=? AND u.password=?")//
				.setParameter(0, loginName)//
				.setParameter(1, md5Digest)//
				.uniqueResult();*/
		//studentDao.findByIdAndPassword(t, id, password)
		return (Student) studentDao.findByIdAndPassword(s, sid, password);
	}

	public Collection<Student> getStudentsBySubIds(List<Long> ids) {
		// TODO Auto-generated method stub
		return this.studentDao.getStudentsBySubIds(ids);
	}

}
