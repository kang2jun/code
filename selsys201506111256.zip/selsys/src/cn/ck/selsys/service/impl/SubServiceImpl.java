package cn.ck.selsys.service.impl;

import java.io.Serializable;
import java.util.Collection;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import cn.ck.selsys.dao.SubDao;
import cn.ck.selsys.dao.base.impl.BaseDaoImpl;
import cn.ck.selsys.domain.Sub;
import cn.ck.selsys.service.SubService;

@Service("subService")
public class SubServiceImpl extends BaseDaoImpl<Sub> implements SubService{
	@Resource(name="subDao")
	private SubDao subDao;
	
	@Transactional(readOnly=false)
	public void deleteSubById(Serializable id, String deleteMode) {
		// TODO Auto-generated method stub
		this.subDao.deleteEntry(id);
	}

	public Collection<Sub> getAllSub() {
		// TODO Auto-generated method stub
		return this.subDao.getAllEntry();
	}

	public Sub getSubById(Serializable id) {
		// TODO Auto-generated method stub
		return (Sub) this.subDao.getEntryById(id);
	}

	@Transactional(readOnly=false)
	public void saveSub(Sub sub) {
		// TODO Auto-generated method stub
		this.subDao.saveEntry(sub);
	}

	@Transactional(readOnly=false)
	public void updateSub(Sub sub) {
		// TODO Auto-generated method stub
		this.subDao.updateEntry(sub);
	}

	public Collection<Sub> getSubsByDid(Serializable id) {
		// TODO Auto-generated method stub
		return this.subDao.getSubsByDid(id);
	}
	
}
