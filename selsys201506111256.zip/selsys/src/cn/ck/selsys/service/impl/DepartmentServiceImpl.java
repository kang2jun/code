package cn.ck.selsys.service.impl;

import java.io.Serializable;
import java.util.Collection;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import cn.ck.selsys.dao.DepartmentDao;
import cn.ck.selsys.dao.base.impl.BaseDaoImpl;
import cn.ck.selsys.domain.Department;
import cn.ck.selsys.service.DepartmentService;

@Service("departmentService")
public class DepartmentServiceImpl extends BaseDaoImpl<Department> implements DepartmentService{
	@Resource(name="departmentDao")
	private DepartmentDao departmentDao;

	@Transactional(readOnly=false)
	public void deleteDepartmentById(Serializable id,String deleteMode) {
		// TODO Auto-generated method stub
		this.departmentDao.deleteEntry(id);
	}

	//@JSON(serialize=false)
	public Collection<Department> getAllDepartment() {
		// TODO Auto-generated method stub
		//return this.departmentDao.getAllDepartment();
		//int a = 1/0;
		return this.departmentDao.getAllEntry();
	}

	public Department getDepartmentById(Serializable id) {
		// TODO Auto-generated method stub
		return (Department) this.departmentDao.getEntryById(id);
	}

	@Transactional(readOnly=false)
	public void saveDepartment(Department department) {
		// TODO Auto-generated method stub
		//this.departmentDao.saveDepartment(department);
		this.departmentDao.saveEntry(department);
	}

	@Transactional(readOnly=false)
	public void updateDepartment(Department department) {
		// TODO Auto-generated method stub
		this.departmentDao.updateEntry(department);
	}
	
}
