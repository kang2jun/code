package cn.ck.selsys.service.impl;

import java.io.Serializable;
import java.util.Collection;

import javax.annotation.Resource;

import org.springframework.stereotype.Repository;

import cn.ck.selsys.dao.TeacherDao;
import cn.ck.selsys.dao.base.impl.BaseDaoImpl;
import cn.ck.selsys.domain.Teacher;
import cn.ck.selsys.service.TeacherService;

@Repository("teacherService")
public class TeacherServiceImpl extends BaseDaoImpl<Teacher> implements TeacherService{
	
	@Resource(name="teacherDao")
	private TeacherDao teacherDao;

	public void deleteTeacherById(Serializable id, String deleteMode) {
		// TODO Auto-generated method stub
		this.teacherDao.deleteEntry(id);
	}

	public Collection<Teacher> getAllTeacher() {
		// TODO Auto-generated method stub
		return this.teacherDao.getAllEntry();
	}

	public Teacher getTeacherById(Serializable id) {
		// TODO Auto-generated method stub
		return (Teacher) this.teacherDao.getEntryById(id);
	}

	public void saveTeacher(Teacher teacher) {
		// TODO Auto-generated method stub
		this.teacherDao.saveEntry(teacher);
	}

	public void updateTeacher(Teacher teacher) {
		// TODO Auto-generated method stub
		this.teacherDao.updateEntry(teacher);
	}

	public Teacher findByLoginNameAndPassword(Teacher t, Long tid, String password) {
		// TODO Auto-generated method stub
		return (Teacher) teacherDao.findByIdAndPassword(t, tid, password);
	}

	public Collection<Teacher> getTeachersByDid(Long did) {
		// TODO Auto-generated method stub
		return this.teacherDao.getTeachersByDid(did);
	}

}
