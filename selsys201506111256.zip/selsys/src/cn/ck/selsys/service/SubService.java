package cn.ck.selsys.service;

import java.io.Serializable;
import java.util.Collection;

import cn.ck.selsys.dao.base.BaseDao;
import cn.ck.selsys.domain.Sub;

public interface SubService extends BaseDao<Sub>{
	public void saveSub(Sub sub);

	public void updateSub(Sub sub);

	public void deleteSubById(Serializable id,String deleteMode);

	public Collection<Sub> getAllSub();

	public Sub getSubById(Serializable id);
	
	public Collection<Sub> getSubsByDid(Serializable id);

}
