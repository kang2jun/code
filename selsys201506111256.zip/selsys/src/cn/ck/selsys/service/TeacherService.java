package cn.ck.selsys.service;

import java.io.Serializable;
import java.util.Collection;

import cn.ck.selsys.dao.base.BaseDao;
import cn.ck.selsys.domain.Teacher;

public interface TeacherService extends BaseDao<Teacher>{
	public void saveTeacher(Teacher teacher);

	public void updateTeacher(Teacher teacher);

	public void deleteTeacherById(Serializable id,String deleteMode);

	public Collection<Teacher> getAllTeacher();

	public Teacher getTeacherById(Serializable id);

	public Teacher findByLoginNameAndPassword(Teacher t, Long tid, String password);
	
	public Collection<Teacher> getTeachersByDid(Long did);

}
