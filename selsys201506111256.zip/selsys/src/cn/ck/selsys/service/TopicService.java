package cn.ck.selsys.service;

import java.io.Serializable;
import java.util.Collection;

import cn.ck.selsys.dao.base.BaseDao;
import cn.ck.selsys.domain.Topic;

public interface TopicService extends BaseDao<Topic>{
	public void saveTopic(Topic topic);

	public void updateTopic(Topic topic);

	public void deleteTopicById(Serializable id,String deleteMode);

	public Collection<Topic> getAllTopic();

	public Topic getTopicById(Serializable id);
	
	public Collection<Topic> getTopicsByTid(Long tid);
	
	public Collection<Topic> getTopicsByDid(Long did);

}
