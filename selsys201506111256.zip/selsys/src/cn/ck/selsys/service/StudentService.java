package cn.ck.selsys.service;

import java.io.Serializable;
import java.util.Collection;
import java.util.List;

import cn.ck.selsys.dao.base.BaseDao;
import cn.ck.selsys.domain.Student;

public interface StudentService extends BaseDao<Student>{
	
	public void saveStudent(Student student);

	public void updateStudent(Student student);

	public void deleteStudentById(Serializable id,String deleteMode);

	public Collection<Student> getAllStudent();

	public Student getStudentById(Serializable id);
	
	public Student findByLoginNameAndPassword(Student s ,Serializable sid, String password);
	
	public Collection<Student> getStudentsBySubIds(List<Long> ids);
}
