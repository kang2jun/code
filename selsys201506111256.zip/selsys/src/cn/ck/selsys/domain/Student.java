package cn.ck.selsys.domain;

import java.io.Serializable;
import java.util.List;

public class Student implements Serializable {
	private Long sid;//学号
	private String sname;//真名
	private String gender;//性别
	private String password;//密码
	private String phone;//号码
	private String email;//电子邮件信箱
	private Long level;//年级
	private Boolean canselect;//是否有选题资格
	private Boolean isselect;//是否选题成功了，最终匹配状态
	
	private Long selecttime;//选题时间
	private String description;//描述
	private String classroom;//班级，因为class是关键字，我实在想不出来其他单词了
	
	private Sub sub;//专业
	
	
	
	public Boolean getIsselect() {
		return isselect;
	}
	public void setIsselect(Boolean isselect) {
		this.isselect = isselect;
	}
	public Sub getSub() {
		return sub;
	}
	public void setSub(Sub sub) {
		this.sub = sub;
	}
	public Long getLevel() {
		return level;
	}
	public void setLevel(Long level) {
		this.level = level;
	}
	public String getClassroom() {
		return classroom;
	}
	public void setClassroom(String classroom) {
		this.classroom = classroom;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public Long getSelecttime() {
		return selecttime;
	}
	public void setSelecttime(Long selecttime) {
		this.selecttime = selecttime;
	}
	public Boolean getCanselect() {
		return canselect;
	}
	public void setCanselect(Boolean canselect) {
		this.canselect = canselect;
	}
	//private Department department;
	private List<Topic> topics;//预选课题s
	//private Topic topic;//预选第一位及
	public Long getSid() {
		return sid;
	}
	public void setSid(Long sid) {
		this.sid = sid;
	}
	public String getSname() {
		return sname;
	}
	public void setSname(String sname) {
		this.sname = sname;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getPhone() {
		return phone;
	}
	public void setPhone(String phone) {
		this.phone = phone;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public List<Topic> getTopics() {
		return topics;
	}
	public void setTopics(List<Topic> topics) {
		this.topics = topics;
	}
	
	
	
}
