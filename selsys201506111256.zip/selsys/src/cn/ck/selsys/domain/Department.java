package cn.ck.selsys.domain;

import java.io.Serializable;
import java.util.Set;

/**
 * 学院
 * @author ck
 *
 */
public class Department implements Serializable{
	private Long did;
	private String dname;
	private String description;
	
	//private Set<Student> students;
	private Set<Teacher> teachers;
	private Set<Sub> subs;
	
	  
	
	public Set<Sub> getSubs() {
		return subs;
	}
	public void setSubs(Set<Sub> subs) {
		this.subs = subs;
	}
	public Long getDid() {
		return did;
	}
	public void setDid(Long did) {
		this.did = did;
	}
	public String getDname() {
		return dname;
	}
	public void setDname(String dname) {
		this.dname = dname;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public Set<Teacher> getTeachers() {
		return teachers;
	}
	public void setTeachers(Set<Teacher> teachers) {
		this.teachers = teachers;
	}
}
