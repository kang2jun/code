package cn.ck.selsys.domain;

import java.io.Serializable;

/**
 * 管理员(超级管理员)
 * @author ck
 *
 */
public class Man implements Serializable{
	private Long mid;//man号
	private String mname;
	private String password;
	private String phone;
	private String email;
	

	public Long getMid() {
		return mid;
	}

	public void setMid(Long mid) {
		this.mid = mid;
	}

	

	public String getMname() {
		return mname;
	}

	public void setMname(String mname) {
		this.mname = mname;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getPhone() {
		return phone;
	}

	public void setPhone(String phone) {
		this.phone = phone;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}
	
	//private Boolean isadmin;//是否是学院的管理员老师（指定学生选定某个课题，匹配没选的课题和学生：普通老师只能发布课题，不能直接决定学生的选题，因为学生可能选择多个老师的课题，要公平）
}
