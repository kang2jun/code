package cn.ck.selsys.domain;

import java.io.Serializable;
import java.util.Set;

public class Teacher implements Serializable{
	private Long tid;//工号
	private String tname;//真名
	private String gender;//性别
	private String password;
	private String phone;
	private String email;
	private String description;
	private Boolean isadmin;
	
	
	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public Boolean getIsadmin() {
		return isadmin;
	}

	public void setIsadmin(Boolean isadmin) {
		this.isadmin = isadmin;
	}

	private Department department; 
	
	private Set<Topic> topics;

	public Long getTid() {
		return tid;
	}

	public void setTid(Long tid) {
		this.tid = tid;
	}

	public String getTname() {
		return tname;
	}

	public void setTname(String tname) {
		this.tname = tname;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getPhone() {
		return phone;
	}

	public void setPhone(String phone) {
		this.phone = phone;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public Department getDepartment() {
		return department;
	}

	public void setDepartment(Department department) {
		this.department = department;
	}

	public Set<Topic> getTopics() {
		return topics;
	}

	public void setTopics(Set<Topic> topics) {
		this.topics = topics;
	}
	
	
	
	
	//private Boolean isadmin;//是否是学院的管理员老师（指定学生选定某个课题，匹配没选的课题和学生：普通老师只能发布课题，不能直接决定学生的选题，因为学生可能选择多个老师的课题，要公平）
}
