package cn.ck.selsys.domain;

import java.util.Set;

public class Sub {
	private Long subid;
	private String subname;
	private String subdesc;
	
	
	private Department department;
	private Set<Student> students;
	public Long getSubid() {
		return subid;
	}
	public void setSubid(Long subid) {
		this.subid = subid;
	}
	public String getSubname() {
		return subname;
	}
	public void setSubname(String subname) {
		this.subname = subname;
	}
	public String getSubdesc() {
		return subdesc;
	}
	public void setSubdesc(String subdesc) {
		this.subdesc = subdesc;
	}
	public Department getDepartment() {
		return department;
	}
	public void setDepartment(Department department) {
		this.department = department;
	}
	public Set<Student> getStudents() {
		return students;
	}
	public void setStudents(Set<Student> students) {
		this.students = students;
	}
	
	
}
