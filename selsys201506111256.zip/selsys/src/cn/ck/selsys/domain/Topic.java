package cn.ck.selsys.domain;

import java.io.Serializable;

/**
 * 学生预选题，student有值，故不展示（别的同学看不见了），当系统确定选题或者由man指定后ischeck为true，确定其他题后student则为空
 * @author ck
 *
 */
public class Topic implements Serializable{
	
	private Long topicid;
	private String tname;
	private String description;
	private Boolean ischeck;//是否已经选定了，没选定每晚系统结算时才会遍历到这个课题，选定了就不管了
	private Long time;//预选题时间，遍历时以这个排序
	
	private String year;//申报学年：2014-2015   --> 2015(2011+4)
	private String selectmode;//选题模式:学生自选
	private String source;//选题来源：教师自拟课题
	private String type;//类型：技术开发
	private String level;//课题难易度：适中
	private String workload;//课题工作量：适中
	private String train;//综合性训练程度:中
	private String requirements;//毕业设计(论文)要求
	private String subname;
	
	
	public String getSubname() {
		return subname;
	}
	public void setSubname(String subname) {
		this.subname = subname;
	}
	private Teacher teacher;
	private Student student;
	
	public String getYear() {
		return year;
	}
	public void setYear(String year) {
		this.year = year;
	}
	public String getSelectmode() {
		return selectmode;
	}
	public void setSelectmode(String selectmode) {
		this.selectmode = selectmode;
	}
	public String getSource() {
		return source;
	}
	public void setSource(String source) {
		this.source = source;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public String getLevel() {
		return level;
	}
	public void setLevel(String level) {
		this.level = level;
	}
	public String getWorkload() {
		return workload;
	}
	public void setWorkload(String workload) {
		this.workload = workload;
	}
	public String getTrain() {
		return train;
	}
	public void setTrain(String train) {
		this.train = train;
	}
	public String getRequirements() {
		return requirements;
	}
	public void setRequirements(String requirements) {
		this.requirements = requirements;
	}
	
	
	public Long getTopicid() {
		return topicid;
	}
	public void setTopicid(Long topicid) {
		this.topicid = topicid;
	}
	public String getTname() {
		return tname;
	}
	public void setTname(String tname) {
		this.tname = tname;
	}
	
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public Boolean getIscheck() {
		return ischeck;
	}
	public void setIscheck(Boolean ischeck) {
		this.ischeck = ischeck;
	}
	public Long getTime() {
		return time;
	}
	public void setTime(Long time) {
		this.time = time;
	}
	public Teacher getTeacher() {
		return teacher;
	}
	public void setTeacher(Teacher teacher) {
		this.teacher = teacher;
	}
	public Student getStudent() {
		return student;
	}
	public void setStudent(Student student) {
		this.student = student;
	}
	
	
}
