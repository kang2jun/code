package cn.ck.selsys.utils;

import cn.ck.selsys.domain.Man;
import cn.ck.selsys.domain.Student;
import cn.ck.selsys.domain.Teacher;

import com.opensymphony.xwork2.ActionContext;
import com.opensymphony.xwork2.ActionInvocation;
import com.opensymphony.xwork2.interceptor.AbstractInterceptor;

public class CheckPrivilegeInterceptor extends AbstractInterceptor {
	
	//StrutsPrepareAndExecuteFilter

	public String intercept(ActionInvocation invocation) throws Exception {
		// System.out.println("---------> 之前");
		// String result = invocation.invoke(); // 放行
		// System.out.println("---------> 之后");
		// return result;

		// 获取信息
		//User user = (User) ActionContext.getContext().getSession().get("user"); // 当前登录用户
		String namespace = invocation.getProxy().getNamespace();
		String actionName = invocation.getProxy().getActionName();
		String privUrl = namespace + actionName; // 对应的权限URL
		
		if(privUrl.startsWith("/studentAction")){
			Student student = (Student) ActionContext.getContext().getSession().get("student");
			Teacher teacher = (Teacher) ActionContext.getContext().getSession().get("teacher");
			if(privUrl.startsWith("/studentAction_showmsg")){
				return invocation.invoke();
			}
			if(student == null){
				if (privUrl.startsWith("/studentAction_login")) { // "/user_loginUI", "/user_login"
					// 如果是去登录，就放行
					System.out.println("放行");
					return invocation.invoke();
				} else {
					//学生管理主页的访问
					if(privUrl.startsWith("/studentAction_index")){
						System.out.println("转到登录页面");
						return "loginUI";
					}
					//学院管理员管理学生
					else if(teacher!=null&&teacher.getIsadmin()){
						return invocation.invoke();
					}
					// 如果不是去登录，就转到登录页面
					System.out.println("转到登录页面");
					return "loginUI";
				}
			}
			System.out.println("放行");
			return invocation.invoke();
		}else if(privUrl.startsWith("/teacherAction")){
			Teacher teacher = (Teacher) ActionContext.getContext().getSession().get("teacher");
			Man man = (Man) ActionContext.getContext().getSession().get("man");
			if(privUrl.startsWith("/teacherAction_showmsg")){
				return invocation.invoke();
			}
			if(teacher == null && man==null){
				if (privUrl.startsWith("/teacherAction_login")) { // "/user_loginUI", "/user_login"
					// 如果是去登录，就放行
					return invocation.invoke();
				} else {
					// 如果不是去登录，就转到登录页面
					return "loginUI";
				}
			}
			if(man!=null&&privUrl.startsWith("/teacherAction_index")){
				//教师管理主页的访问，系统管理员不能访问
				System.out.println("转到登录页面");
				return "loginUI";
			}
			return invocation.invoke();
		}else if(privUrl.startsWith("/manAction")){
			Man man = (Man) ActionContext.getContext().getSession().get("man");
			if(man == null){
				if (privUrl.startsWith("/manAction_login")) { // "/user_loginUI", "/user_login"
					// 如果是去登录，就放行
					return invocation.invoke();
				} else {
					// 如果不是去登录，就转到登录页面
					return "loginUI";
				}
			}
			return invocation.invoke();
		}else if(privUrl.startsWith("/departmentAction")){
			Man man = (Man) ActionContext.getContext().getSession().get("man");
			if(man != null){
				return invocation.invoke();
			}
			return null;
		}else if(privUrl.startsWith("/topicAction")){
			Teacher teacher = (Teacher) ActionContext.getContext().getSession().get("teacher");
			Student student = (Student) ActionContext.getContext().getSession().get("student");
			if(teacher != null){
				return invocation.invoke();
			}else if(student != null && (privUrl.startsWith("/topicAction_select")||privUrl.startsWith("/topicAction_list"))){
				return invocation.invoke();
			}
			return null;
		}else if(privUrl.startsWith("/subAction")){
			Teacher teacher = (Teacher) ActionContext.getContext().getSession().get("teacher");
			if(teacher != null){
				return invocation.invoke();
			}
			return null;
		}else{
			return null;
		}

		// 如果未登录
		/*if (user == null) {
			if (privUrl.startsWith("/user_login")) { // "/user_loginUI", "/user_login"
				// 如果是去登录，就放行
				return invocation.invoke();
			} else {
				// 如果不是去登录，就转到登录页面
				return "loginUI";
			}
		}
		// 如果已登 录，就判断权限
		else {
			if (user.hasPrivilegeByUrl(privUrl)) {
				// 如果有权限，就放行
				return invocation.invoke();
			} else {
				// 如果没有权限，就转到提示页面
				return "noPrivilegeError";
			}
		}*/
	}

}
