package cn.ck.selsys.utils;

import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import cn.ck.selsys.domain.Department;
import cn.ck.selsys.domain.Student;
import cn.ck.selsys.domain.Topic;
import cn.ck.selsys.service.DepartmentService;
import cn.ck.selsys.service.StudentService;

public class Test {
	public static void mainfs() {
		ApplicationContext context = new ClassPathXmlApplicationContext("spring/applicationContext.xml");
		StudentService studentService = (StudentService) context.getBean("studentService");
		/*DepartmentService departmentService = (DepartmentService) context.getBean("departmentService");
		Department d1 = new Department();
		d1.setDname("计算机学院");
		departmentService.saveDepartment(d1);
		
		Student student = new Student();
		student.setSid(2L);
		student.setSname("ck");
		Student s2 = new Student();
		s2.setSname("haha");
		Set<Student> students = new HashSet<Student>();
		students.add(student);
		students.add(s2);*/
		//d1.setStudents(students);
		
		/*studentService.saveStudent(student);
		studentService.saveStudent(s2);*/
		//Student s1 = studentService.getStudentById(1L);
		//System.out.println(s1.getSname());
		Student s1 = studentService.getStudentById(20111555L);
		System.out.println(s1.getSname());
		List<Topic> topics = s1.getTopics();
		Topic t3 = topics.get(0);
		Topic t1 = topics.get(1);
		Topic t2 = topics.get(2);
		topics.clear();
		topics.add(t1);
		topics.add(t2);
		topics.add(t3);
		s1.setTopics(topics);
		studentService.updateStudent(s1);
	}
	
	public static void main(String[] args) {
		Date date = new Date();
		long time = date.getTime();
		System.out.println(date.getYear()+1900);
		//1430574241672 
		//1430574247818
		//1430574273496
		//1430574294774
		//1430574330420
		//1430574525842
		System.out.println(md5.md5("123456"));
		
	}

}
