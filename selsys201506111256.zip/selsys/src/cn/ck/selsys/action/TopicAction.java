package cn.ck.selsys.action;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.annotation.Resource;

import org.springframework.beans.BeanUtils;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Controller;

import cn.ck.selsys.action.base.BaseAction;
import cn.ck.selsys.domain.PageBean;
import cn.ck.selsys.domain.Student;
import cn.ck.selsys.domain.Sub;
import cn.ck.selsys.domain.Teacher;
import cn.ck.selsys.domain.Topic;
import cn.ck.selsys.service.StudentService;
import cn.ck.selsys.service.SubService;
import cn.ck.selsys.service.TeacherService;
import cn.ck.selsys.service.TopicService;
import cn.ck.selsys.utils.QueryHelper;

import com.opensymphony.xwork2.ActionContext;

@Controller("topicAction")
@Scope("prototype")
public class TopicAction extends BaseAction<Topic>{
	@Resource(name="topicService")
	private TopicService topicService;
	
	@Resource(name="studentService")
	private StudentService studentService;
	static List<String> typeList ;
	static List<Integer> levelList = new ArrayList<Integer>();
	
	static{
		typeList = new ArrayList<String>();
		typeList.add("技术开发");
		typeList.add("应用研究");
		typeList.add("理论研究");
		int year = new Date().getYear()+1900;
		for(int i = year; i > 2001; i--){
			levelList.add(i);
		}
	}
	
	//课题所属教师的id
	private Long tid;

	public Long getTid() {
		return tid;
	}

	public void setTid(Long tid) {
		this.tid = tid;
	}
	
	private Long sid;
	
	public Long getSid() {
		return sid;
	}

	public void setSid(Long sid) {
		this.sid = sid;
	}

	private String teachername;

	public String getTeachername() {
		return teachername;
	}

	public void setTeachername(String teachername) {
		this.teachername = teachername;
	}

	@Resource(name="teacherService")
	private TeacherService teacherService;
	
	/** 列表 */
	public String list(){
		String addSql = "";
		if(this.getModel().getType()!=null&&this.getModel().getType().toString().trim().length()>0){
			addSql += " and to.type='"+this.getModel().getType()+"'";
		}
		if(getTeachername()!=null&&getTeachername().toString().trim().length()>0){
			addSql += " and to.teacher.tname='"+getTeachername()+"'";
		}
		if(ActionContext.getContext().getSession().get("stuid")!=null){
			ActionContext.getContext().getSession().remove("stuid");
		}
		String year = new Date().getYear()+1900+"";
		List<Topic> topicList = null;
		Teacher teacher = (Teacher) ActionContext.getContext().getSession().get("teacher");
		Student student = (Student) ActionContext.getContext().getSession().get("student");
		if(teacher != null){
			//学院管理员指定未选题的学生选择课题
			if(sid!=null&&sid.toString().trim().length()>0){
				Sub sub = studentService.getStudentById(sid).getSub();
				new QueryHelper(Topic.class, "to")//
				.addCondition(" where to.subname='"+sub.getSubname()+"'"+addSql)//
				.addCondition("to.year=?",year)
				.addOrderProperty("to.topicid", false)
				.preparePageBean(topicService, pageNum, pageSize);
				//准备教师和类型的数据
				List<Teacher> teacherList = (List<Teacher>) teacherService.getTeachersByDid(sub.getDepartment().getDid());
				ActionContext.getContext().put("teacherList", teacherList);
				ActionContext.getContext().put("typeList", typeList);
				ActionContext.getContext().put("teachername", this.getTeachername());
				ActionContext.getContext().put("type", this.getModel().getType());
				ActionContext.getContext().put("sid", sid);
				return "pointlist";
			}
			//教师查询自己提交的课题
			new QueryHelper(Topic.class, "to")//
			.addCondition(" where to.teacher.tid='"+teacher.getTid()+"'")//
			.addOrderProperty("to.topicid", false)
			.preparePageBean(topicService, pageNum, pageSize);
			return "list";
		}else if(student != null){//学生差选可选的课题
			try {
				Sub sub = studentService.getStudentById(student.getSid()).getSub();
				new QueryHelper(Topic.class, "to")//
				.addCondition(" where to.subname='"+sub.getSubname()+"'"+addSql)//
				.addCondition("to.year=?",year)
				.addOrderProperty("to.topicid", false)
				.preparePageBean(topicService, pageNum, pageSize);
				//准备教师和类型的数据
				List<Teacher> teacherList = (List<Teacher>) teacherService.getTeachersByDid(sub.getDepartment().getDid());
				ActionContext.getContext().put("teacherList", teacherList);
				ActionContext.getContext().put("typeList", typeList);
				ActionContext.getContext().put("teachername", this.getTeachername());
				ActionContext.getContext().put("type", this.getModel().getType());
				return "list";
			} catch (Exception e) {
				ActionContext.getContext().put("msg","专业不存在或学院不存在");
				return "ErrorPage";
			}
		}else{
			ActionContext.getContext().put("msg","出现异常");
			return "ErrorPage";
		}
		/*if(teacher==null){
			topicList = (List<Topic>) this.topicService.getAllTopic();
		}else{			
			topicList = (List<Topic>) this.topicService.getTopicsByTid(teacher.getTid());
		}
		ActionContext.getContext().put("topicList", topicList);*/
		// 准备分页信息
	}
	

	
	
	@Resource(name="subService")
	private SubService subService;
	/** 删除 */
	public String delete() throws Exception {
		topicService.deleteTopicById(this.getModel().getTopicid(), "all");
		return "toList";
	}
	
	/** 添加页面 */
	public String addUI() throws Exception {
		Teacher teacher = (Teacher) ActionContext.getContext().getSession().get("teacher");
		List<Sub> subList = (List<Sub>) subService.getSubsByDid(teacher.getDepartment().getDid());
		ActionContext.getContext().put("subList", subList);
		ActionContext.getContext().put("typeList", typeList);
		ActionContext.getContext().put("levelList", levelList);
		return "saveUI";
	}
	
	/** 添加 */
	public String add() throws Exception {
		// 保存
		Topic topic = this.getModel();
		Teacher teacher = (Teacher) ActionContext.getContext().getSession().get("teacher");
		topic.setTeacher(teacher);
		topic.setIscheck(false);
		topicService.saveTopic(this.getModel());
		return "toList";
	}
	
	/** 修改页面 */
	public String editUI() throws Exception {		
		Teacher teacher = (Teacher) ActionContext.getContext().getSession().get("teacher");
		List<Sub> subList = (List<Sub>) subService.getSubsByDid(teacher.getDepartment().getDid());
		ActionContext.getContext().put("subList", subList);
		
		//准备回显数据
		Topic topic = topicService.getTopicById(this.getModel().getTopicid());
		//ActionContext.getContext().put("subname", topic.getSubname());
		ActionContext.getContext().getValueStack().push(topic);
		ActionContext.getContext().put("typeList", typeList);
		ActionContext.getContext().put("levelList", levelList);
		return "saveUI";
	}
	
	
	
	/** 修改 */
	public String edit() throws Exception {
		// 1，从数据库取出原对象
		Topic topic = topicService.getTopicById(this.getModel().getTopicid());
		Topic t1 = this.getModel();
		t1.setTime(topic.getTime());
		t1.setIscheck(topic.getIscheck());
		t1.setTeacher(topic.getTeacher());
		t1.setStudent(topic.getStudent());

		// 2，设置要修改的属性
		BeanUtils.copyProperties(this.getModel(), topic);
		
		// 3，更新到数据库中
		topicService.updateTopic(topic);
		return "toList";
	}
	
	//审核页面
	public String decideUI(){
		Topic topic = topicService.getTopicById(this.getModel().getTopicid());
		Student student = topic.getStudent();
		ActionContext.getContext().put("student", student);
		ActionContext.getContext().getValueStack().push(topic);
		return "decideUI";//E6F5FF
	}
	
	public String decide(){
		Topic topic = topicService.getTopicById(this.getModel().getTopicid());
		Student student = topic.getStudent();
		
		topic.setIscheck(true);
		//List<Topic> topics = student.getTopics();
		ArrayList<Topic> topicList = new ArrayList<Topic>();
		topicList.add(topic);
		student.setTopics(topicList);
		student.setIsselect(true);
		studentService.updateStudent(student);
		topicService.updateTopic(topic);
		if(ActionContext.getContext().getSession().get("stuid")!=null){
			ActionContext.getContext().getSession().remove("stuid");
			return "studentList";
		}
		return "toList";
	}
	
	
	//审核不通过
	public String cancel(){
		Topic topic = topicService.getTopicById(this.getModel().getTopicid());
		Student student = topic.getStudent();
		List<Topic> topics = student.getTopics();
		for(int i = 0; i < topics.size(); i++){
			if(topics.get(i).getTopicid().equals(topic.getTopicid())){
				topics.remove(i);
				break;
			}
		}
		topic.setStudent(null);
		topicService.updateTopic(topic);
		student.setTopics(topics);
		studentService.updateStudent(student);
		if(ActionContext.getContext().getSession().get("stuid")!=null){
			ActionContext.getContext().getSession().remove("stuid");
			return "studentList";
		}
		return "toList";
	}
	
	/** 选题页面 */
	public String selectUI() throws Exception {		
		Topic topic = topicService.getTopicById(this.getModel().getTopicid());
		ActionContext.getContext().getValueStack().push(topic);
		if(getSid()!=null&&getSid().toString().trim().length()>0){
			ActionContext.getContext().put("sid", getSid());
			return "pointselectUI";
		}
		return "selectUI";
	}
	
	
	//pointUI
	//教师指定某个课题给某个学生的页面
	public String pointUI(){
		Topic topic = topicService.getTopicById(this.getModel().getTopicid());
		ActionContext.getContext().getValueStack().push(topic);
		return "pointUI";
	}
	
	//将某个课题指定给学生
	public String point(){
		Student student = studentService.getStudentById(getSid());
		if(student == null){
			ActionContext.getContext().put("msg", "该学生不存在");
			return "ErrorPage";
		}
		if(student.getIsselect()){
			ActionContext.getContext().put("msg", "该学生已经选定了，没法指定");
			return "ErrorPage";
		}else if(student.getCanselect()==null||student.getCanselect()!=true){
			ActionContext.getContext().put("msg", "该学生没有选题权限，请联系学院管理员");
			return "ErrorPage";
		}
		Topic topic = topicService.getTopicById(this.getModel().getTopicid());
		List<Topic> topicList = student.getTopics();
		if(topic.getStudent()==null){
			if(topicList.size()<3){
				topicList.add(topic);
			}else{
				topicList.remove(2);
				topicList.add(2, topic);
			}
			topic.setStudent(student);
			student.setTopics(topicList);
			studentService.updateStudent(student);
			topicService.updateTopic(topic);
		}
		return "toList";
	}
	
	//选题逻辑
	public String select(){
		
		Student student = studentService.getStudentById(sid);
		if(student.getCanselect()==null||student.getCanselect()!=true){
			ActionContext.getContext().put("msg", "该学生没有选题权限，请联系学院管理员");
			return "ErrorPage";
		}
		Topic topic = topicService.getTopicById(this.getModel().getTopicid());
		List<Topic> topicList = student.getTopics();
		if(topic.getStudent()==null){
			if(topicList.size()<3){
				topicList.add(topic);
			}else{
				topicList.remove(2);
				topicList.add(2, topic);
			}
			topic.setStudent(student);
			student.setTopics(topicList);
			studentService.updateStudent(student);
			topicService.updateTopic(topic);
		}
		ActionContext.getContext().getSession().put("stuid", sid);
		Teacher t1 = (Teacher) ActionContext.getContext().getSession().get("teacher");
		if(t1!=null){
			Teacher teacher = teacherService.getTeacherById(t1.getTid());
			if(teacher.getIsadmin()){
				return "studentList";
			}
		}
		return "toShow";
	}
	
	
	//显示学生自己的课题选择情况
	//studentList --->  student.isselect? null:isselect 
	//---->   student.topics ----> size<1 ? 指定课题  ：审核
	public String selectshow(){
		if(sid == null){
			sid = (Long) ActionContext.getContext().getSession().get("stuid");
		}
		Student student = studentService.getStudentById(sid);
		List<Topic> recordList = student.getTopics();
		PageBean pageBean = new PageBean(1, 10, 10, recordList);
		ActionContext.getContext().getValueStack().push(pageBean);
		ActionContext.getContext().getSession().put("stuid", sid);
		return "show";
	}
	
	//移除选中课题
	public String selectremove(){
		Student student = studentService.getStudentById(sid);
		Long topid = this.getModel().getTopicid();
		//Topic topic = topicService.getTopicById(this.getModel().getTopicid());
		
		List<Topic> topicList = student.getTopics();
		System.out.println(topicList.size());
		Topic topic2;
		for(int i = 0; i < topicList.size(); i++){
			topic2 = topicList.get(i);
			if(topid.equals(topic2.getTopicid())){
				topicList.remove(i);
				topic2.setStudent(null);
				topicService.updateTopic(topic2);
			}
		}
		ActionContext.getContext().getSession().put("stuid", sid);
		return "toShow";
	}
	
	//置顶课题
	public String selectmost(){
		Student student = studentService.getStudentById(sid);
		Long topid = this.getModel().getTopicid();
		List<Topic> topicList = student.getTopics();
		/*if(topid==topicList.get(1).getTopicid()){
			Topic topic = topicList.get(0);
			topicList.set(0, topicList.get(1));
			topicList.set(1, topic);
		}else if(topid==topicList.get(2).getTopicid()){
			
		}*/
		for(int i = 0; i < topicList.size(); i++){
			if(topid.equals(topicList.get(i).getTopicid())){
				Topic topic = topicList.get(i);
				for(int j = i; j > 0; j--){
					topicList.set(j, topicList.get(j-1));
				}
				topicList.set(0, topic);
			}
		}
		student.setTopics(topicList);
		studentService.updateStudent(student);
		ActionContext.getContext().getSession().put("stuid", sid);
		return "toShow";
	}
	
	
	//查看学生信息
	public String showmsg(){
		Student student = null;
		Long topicid = this.getModel().getTopicid();
		Topic topic = null;
		if(topicid != null&&topicid.toString().trim().length()>0){
			topic = topicService.getTopicById(topicid);
			student = topic.getStudent();
			if(student == null){
				ActionContext.getContext().put("msg", "学生不存在");
				return "ErrorPage";
			}
		}else{
			ActionContext.getContext().put("msg", "信息有错");
			return "ErrorPage";
		}
		ActionContext.getContext().put("subname", student.getSub().getSubname());
		ActionContext.getContext().put("student", student);
		ActionContext.getContext().getValueStack().push(topic);
		return "decideUI";//E6F5FF
	}
	
}
