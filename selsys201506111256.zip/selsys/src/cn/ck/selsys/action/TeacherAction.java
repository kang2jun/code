package cn.ck.selsys.action;

import java.util.List;
import java.util.Set;

import javax.annotation.Resource;

import org.springframework.beans.BeanUtils;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Controller;

import cn.ck.selsys.action.base.BaseAction;
import cn.ck.selsys.domain.Department;
import cn.ck.selsys.domain.Teacher;
import cn.ck.selsys.domain.Topic;
import cn.ck.selsys.service.DepartmentService;
import cn.ck.selsys.service.TeacherService;
import cn.ck.selsys.utils.QueryHelper;
import cn.ck.selsys.utils.md5;

import com.opensymphony.xwork2.ActionContext;

@Controller("teacherAction")
@Scope("prototype")
public class TeacherAction extends BaseAction<Teacher> {
	@Resource(name = "teacherService")
	private TeacherService teacherService;
	
	@Resource(name = "departmentService")
	private DepartmentService departmentService;
	
	//记录保存的教师的学院所属
	private Long did;
	
	public Long getDid() {
		return did;
	}

	public void setDid(Long did) {
		this.did = did;
	}

	public String login() {
		if(ActionContext.getContext().getSession().get("student")!=null||ActionContext.getContext().getSession().get("teacher")!=null||ActionContext.getContext().getSession().get("man")!=null){
			ActionContext.getContext().put("msg", "已登录其他账号，请先退出后再操作！");
			return "loginUI";
		}
		Teacher t1 = this.getModel();
		// TODO 密码加密写在这里
		Teacher t = teacherService.findByLoginNameAndPassword(t1, t1.getTid(),
				md5.md5(t1.getPassword()));
		// Student s = studentService.findByLoginNameAndPassword(s1,
		// s1.getSid(),s1.getPassword());
		if (t != null) {
			System.out.println("登录成功:"+t.getPassword());
			ActionContext.getContext().getSession().put("teacher", t);
			return "tolist";
		}
		ActionContext.getContext().put("msg", "不存在此工号和密码对应的教师！");
		return "loginUI";
	}

	public String loginUI() {
		return "loginUI";
	}

	public String index() throws Exception {
		return "index";
	}

	public String top() throws Exception {
		return "top";
	}

	public String bottom() throws Exception {
		return "bottom";
	}

	public String left() throws Exception {
		Teacher teacher = (Teacher) ActionContext.getContext().getSession().get("teacher");
		Department department = teacherService.getTeacherById(teacher.getTid()).getDepartment();
		ActionContext.getContext().put("department", department);
		return "left";
	}

	public String right() throws Exception {
		return "right";
	}

	/** 注销 */
	public String logout() throws Exception {
		ActionContext.getContext().getSession().remove("teacher");
		return "logout";
	}
	
	
	/** 列表 */
	public String list(){
		/*List<Teacher> teacherList = null;
		teacherList = (List<Teacher>) this.teacherService.getAllTeacher();
		ActionContext.getContext().put("teacherList", teacherList);*/
		
		new QueryHelper(Teacher.class, "t")//
		.preparePageBean(teacherService, pageNum, pageSize);
		return "list";
	}
	
	/** 删除 */
	public String delete() throws Exception {
		teacherService.deleteTeacherById(this.getModel().getTid(), "all");
		return "toList";
	}
	
	/** 添加页面 */
	public String addUI() throws Exception {
		//准备数据：学院
		List<Department> departmentList = null;
		departmentList = (List<Department>) this.departmentService.getAllDepartment();
		if(departmentList==null||departmentList.size()<1){
			ActionContext.getContext().put("msg", "尚且没有学院，无法操作教师！ ");
			return "ErrorPage";
		}
		ActionContext.getContext().put("departmentList", departmentList);
		return "saveUI";
	}
	
	/** 添加 */
	public String add() throws Exception {
		// 保存
		Teacher teacher = this.getModel();
		teacher.setDepartment(this.departmentService.getDepartmentById(did));
		teacher.setPassword("4QrcOUm6Wau+VuBX8g+IPg==");
		teacherService.saveTeacher(this.getModel());
		return "toList";
	}
	
	/** 修改页面 */
	public String editUI() throws Exception {
		// 准备回显的数据
		//this.did = (Long) ActionContext.getContext().getValueStack().
/*		this.did = (Long) ServletActionContext.getRequest().getAttribute("did");*/
		List<Department> departmentList = null;
		departmentList = (List<Department>) this.departmentService.getAllDepartment();
		ActionContext.getContext().put("departmentList", departmentList);
		
		
		Teacher session = (Teacher) ActionContext.getContext().getSession().get("teacher");
		Teacher teacher ;
		if(this.getModel().getTid() != null){
			teacher = teacherService.getTeacherById(this.getModel().getTid());
		}else if(session!=null){
			teacher = teacherService.getTeacherById(session.getTid());
		}else{
			teacher = null;
		}
		ActionContext.getContext().put("did", teacher.getDepartment().getDid());
		ActionContext.getContext().getValueStack().push(teacher);
		return "saveUI";
	}
	
	/** 修改 */
	public String edit() throws Exception {
		// 1，从数据库取出原对象
		Teacher teacher = teacherService.getTeacherById(this.getModel().getTid());
		Department department = teacher.getDepartment();
		Boolean isadmin = teacher.getIsadmin();
		Teacher session = (Teacher) ActionContext.getContext().getSession().get("teacher");
		if(session != null){
			did = department.getDid();
			this.getModel().setDepartment(department);
			this.getModel().setIsadmin(isadmin);
		}
		// 2，设置要修改的属性
		/*teacher.setTname(this.getModel().getTname());
		teacher.setDescription(this.getModel().getDescription());*/
		String password = teacher.getPassword();
		Set<Topic> topics = teacher.getTopics();
		BeanUtils.copyProperties(this.getModel(), teacher);
		teacher.setDepartment(this.departmentService.getDepartmentById(did));
		teacher.setPassword(password);
		teacher.setTopics(topics);

		// 3，更新到数据库中
		teacherService.updateTeacher(teacher);
		if(session == null){
			return "toList";
		}else{
			ActionContext.getContext().getSession().remove("teacher");
			ActionContext.getContext().getSession().put("teacher", teacher);
			ActionContext.getContext().put("msg", "修改信息成功！");
			return "msg";
		}
		
	}
	
	//查看教师信息
	public String showmsg(){
		Teacher teacher = null;
		if(this.getModel().getTid() != null){
			teacher = teacherService.getTeacherById(this.getModel().getTid());
			if(teacher == null){
				ActionContext.getContext().put("msg", "教师不存在");
				return "ErrorPage";
			}
		}else{
			ActionContext.getContext().put("msg", "教师不存在");
			return "ErrorPage";
		}
		ActionContext.getContext().put("dname", teacher.getDepartment().getDname());
		ActionContext.getContext().getValueStack().push(teacher);
		return "showmsg";
	}
	
	private String newpass;
	private String newpass1;

	public String getNewpass1() {
		return newpass1;
	}

	public void setNewpass1(String newpass1) {
		this.newpass1 = newpass1;
	}

	public String getNewpass() {
		return newpass;
	}

	public void setNewpass(String newpass) {
		this.newpass = newpass;
	}

	//转到修改密码页面
	public String editpassUI(){
		return "editpassUI";
	}
	
	public String editpass(){
		Teacher t1 = this.getModel();
		Teacher teacher = teacherService.findByLoginNameAndPassword(t1, t1.getTid(), md5.md5(t1.getPassword()));
		if(teacher == null){
			ActionContext.getContext().put("msg", "改密失败：原密码不对！");
			return "ErrorPage";
		}else if(getNewpass()==null||getNewpass().toString().trim().length()<1||getNewpass1()==null||getNewpass1().toString().trim().length()<1){
			ActionContext.getContext().put("msg", "改密失败：新密码不能是空字符串！");
			return "ErrorPage";
		}else if(getNewpass().equals(getNewpass1())){
			teacher.setPassword(md5.md5(this.getNewpass()));
			teacherService.updateTeacher(teacher);
			ActionContext.getContext().put("msg", "改密成功！请重新登录！");
			ActionContext.getContext().getSession().remove("teacher");
			return "msg";
		}else{
			ActionContext.getContext().put("msg", "改密失败：两次密码不一致！");
			return "ErrorPage";
		}
	}

}
