package cn.ck.selsys.action;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Set;

import javax.annotation.Resource;

import org.springframework.beans.BeanUtils;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Controller;

import cn.ck.selsys.action.base.BaseAction;
import cn.ck.selsys.domain.Department;
import cn.ck.selsys.domain.Man;
import cn.ck.selsys.domain.Student;
import cn.ck.selsys.domain.Sub;
import cn.ck.selsys.domain.Teacher;
import cn.ck.selsys.domain.Topic;
import cn.ck.selsys.service.DepartmentService;
import cn.ck.selsys.service.StudentService;
import cn.ck.selsys.service.SubService;
import cn.ck.selsys.utils.QueryHelper;
import cn.ck.selsys.utils.md5;

import com.opensymphony.xwork2.ActionContext;

@Controller("studentAction")
@Scope("prototype")
public class StudentAction extends BaseAction<Student>{
	@Resource(name="studentService")
	private StudentService studentService;
	static List<Integer> levelList = new ArrayList<Integer>();
	static{
		int year = new Date().getYear()+1900;
		for(int i = year; i > 2001; i--){
			levelList.add(i);
		}
	}
	
	public String login(){
		if(ActionContext.getContext().getSession().get("student")!=null
				||ActionContext.getContext().getSession().get("teacher")!=null
				||ActionContext.getContext().getSession().get("man")!=null){
			ActionContext.getContext().put("msg", "已登录其他账号，请先退出后再操作！");
			return "loginUI";
		}
		Student s1 = this.getModel();
		Student s = studentService
		.findByLoginNameAndPassword(s1, s1.getSid(), md5.md5(s1.getPassword()));
		if(s != null){
			System.out.println("登录成功");
			ActionContext.getContext().getSession().put("student", s);
			return "tolist";
		}
		ActionContext.getContext().put("msg", "不存在此学号和密码对应的学生！");
		return "loginUI";
	}
	
	public String loginUI(){
		return "loginUI";
	}
	
	public String index() throws Exception {
		return "index";
	}

	public String top() throws Exception {
		return "top";
	}

	public String bottom() throws Exception {
		return "bottom";
	}

	public String left() throws Exception {
		Student student = (Student) ActionContext.getContext().getSession().get("student");
		Student student2 = studentService.getStudentById(student.getSid());
		Sub sub = student2.getSub();
		ActionContext.getContext().put("sub", sub);
		return "left";
	}

	public String right() throws Exception {
		return "right";
	}
	
	/** 注销 */
	public String logout() throws Exception {
		ActionContext.getContext().getSession().remove("student");
		return "logout";
	}

	
	
	@Resource(name = "departmentService")
	private DepartmentService departmentService;
	
	//记录保存的教师的学院所属
	private Long did;
	
	public Long getDid() {
		return did;
	}

	public void setDid(Long did) {
		this.did = did;
	}
	
	
	/** 列表 */
	public String list(){
		List<Student> studentList = null;
		Teacher teacher = (Teacher) ActionContext.getContext().getSession().get("teacher");
		Department department = departmentService.getDepartmentById(teacher.getDepartment().getDid());
		Set<Sub> subs = department.getSubs();
		List<Sub> subList = new ArrayList<Sub>(subs);
		List<Long> ids = new ArrayList<Long>();
		for(int i = 0; i < subList.size(); i++){
			ids.add(subList.get(i).getSubid());
		}
		/*try {
			studentList = (List<Student>) this.studentService.getStudentsBySubIds(ids);
		} catch (Exception e) {
			ActionContext.getContext().put("msg", "当前没有专业，请先设置专业");
			return "ErrorPage";
		}
		ActionContext.getContext().put("studentList", studentList);*/
		
		
		try {
			new QueryHelper(Student.class, "s")//
			.addInCaluse(" where s.sub.subid in(:alist)",ids)
			.addOrderProperty("s.sid", false)
			.preparePageBean(studentService, pageNum, pageSize);
		} catch (Exception e) {
			ActionContext.getContext().put("msg", "尚且没有专业，无法操作学生！ ");
			return "ErrorPage";
		}
		return "list";
		
		
		/*new QueryHelper(Student.class, "s")//
		.addCondition(" inner join s.sub su where su.department.did='"+teacher.getDepartment().getDid()+"'")//
		.preparePageBean(studentService, pageNum, pageSize);
		return "list";*/
	}
	
	/** 删除 */
	public String delete() throws Exception {
		studentService.deleteStudentById(this.getModel().getSid(), "all");
		return "toList";
	}
	
	@Resource(name="subService")
	private SubService subService;
	
	private Long subid;
	
	public Long getSubid() {
		return subid;
	}

	public void setSubid(Long subid) {
		this.subid = subid;
	}

	/** 添加页面 */
	public String addUI() throws Exception {
		//准备数据：专业
		Teacher teacher = (Teacher) ActionContext.getContext().getSession().get("teacher");
		List<Sub> subList = null;
		subList = (List<Sub>) this.subService.getSubsByDid(teacher.getDepartment().getDid());
		ActionContext.getContext().put("subList", subList);
		ActionContext.getContext().put("levelList", levelList);
		return "saveUI";
	}
	
	/** 添加 */
	public String add() throws Exception {
		// 保存
		Student student = this.getModel();
		//student.setDepartment(this.departmentService.getDepartmentById(did));
		student.setPassword("4QrcOUm6Wau+VuBX8g+IPg==");
		student.setSub(subService.getSubById(this.getSubid()));
		student.setIsselect(false);
		studentService.saveStudent(student);
		return "toList";
	}
	
	/** 修改页面 */
	public String editUI() throws Exception {
		// 准备回显的数据
		//this.did = (Long) ActionContext.getContext().getValueStack().
/*		this.did = (Long) ServletActionContext.getRequest().getAttribute("did");*/
		
		try {
			Teacher teacher = (Teacher) ActionContext.getContext().getSession().get("teacher");
			
			List<Sub> subList = null;
			if(teacher!=null){
				subList = (List<Sub>) this.subService.getSubsByDid(teacher.getDepartment().getDid());
				ActionContext.getContext().put("subList", subList);
				ActionContext.getContext().put("levelList", levelList);
			}
			Student student = studentService.getStudentById(this.getModel().getSid());
			ActionContext.getContext().getValueStack().push(student);
			//ActionContext.getContext().getValueStack().push(this.getSubid());
			ActionContext.getContext().put("subid", student.getSub().getSubid());
			return "saveUI";
		} catch (Exception e) {
			ActionContext.getContext().put("msg","专业不存在或学院不存在");
			return "ErrorPage";
		}
	}
	
	/** 修改 */
	public String edit() throws Exception {
		// 1，从数据库取出原对象
		Student student = studentService.getStudentById(this.getModel().getSid());
		String password = student.getPassword();
		Boolean isselect = student.getIsselect();
		Sub sub = student.getSub();
		Long level = student.getLevel();
		// 2，设置要修改的属性
		/*Student.setTname(this.getModel().getTname());
		Student.setDescription(this.getModel().getDescription());*/
		if(this.getSubid()!=null){
			this.getModel().setSub(subService.getSubById(this.getSubid()));
		}else{
			this.getModel().setCanselect(student.getCanselect());
			this.getModel().setClassroom(student.getClassroom());
			this.getModel().setSub(sub);
			this.getModel().setLevel(level);
		}
		this.getModel().setTopics(student.getTopics());
		BeanUtils.copyProperties(this.getModel(), student);
		//student.setDepartment(this.departmentService.getDepartmentById(did));
		student.setPassword(password);
		student.setIsselect(isselect);
		// 3，更新到数据库中
		studentService.updateStudent(student);
		
		if(ActionContext.getContext().getSession().get("teacher")!=null){
			return "toList";
		}else{
			ActionContext.getContext().getSession().remove("student");
			ActionContext.getContext().getSession().put("student", student);
			ActionContext.getContext().put("msg", "修改信息成功！ ");
			return "msg";
		}
		
	}
	
	private String newpass;
	private String newpass1;

	public String getNewpass1() {
		return newpass1;
	}

	public void setNewpass1(String newpass1) {
		this.newpass1 = newpass1;
	}

	public String getNewpass() {
		return newpass;
	}

	public void setNewpass(String newpass) {
		this.newpass = newpass;
	}

	//转到修改密码页面
	public String editpassUI(){
		return "editpassUI";
	}
	
	public String editpass(){
		Student s1 = this.getModel();
		Student student = studentService.findByLoginNameAndPassword(s1, s1.getSid(), md5.md5(s1.getPassword()));
		if(student == null){
			ActionContext.getContext().put("msg", "改密失败：原密码不对！");
			return "ErrorPage";
		}else if(getNewpass()==null||getNewpass().toString().trim().length()<1||getNewpass1()==null||getNewpass1().toString().trim().length()<1){
			ActionContext.getContext().put("msg", "改密失败：新密码不能是空字符串！");
			return "ErrorPage";
		}else if(getNewpass().equals(getNewpass1())){
			student.setPassword(md5.md5(this.getNewpass()));
			studentService.updateStudent(student);
			ActionContext.getContext().put("msg", "改密成功！请重新登录！");
			ActionContext.getContext().getSession().remove("student");
			return "msg";
		}else{
			ActionContext.getContext().put("msg", "改密失败：两次密码不一致！");
			return "ErrorPage";
		}
	}
}
