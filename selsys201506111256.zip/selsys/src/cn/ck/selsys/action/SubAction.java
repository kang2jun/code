package cn.ck.selsys.action;

import java.util.List;

import javax.annotation.Resource;

import org.springframework.beans.BeanUtils;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Controller;

import cn.ck.selsys.action.base.BaseAction;
import cn.ck.selsys.domain.Department;
import cn.ck.selsys.domain.Sub;
import cn.ck.selsys.domain.Teacher;
import cn.ck.selsys.service.DepartmentService;
import cn.ck.selsys.service.SubService;

import com.opensymphony.xwork2.ActionContext;

@Controller("subAction")
@Scope("prototype")
public class SubAction extends BaseAction<Sub>{
	@Resource(name="subService")
	private SubService subService;
	@Resource(name="departmentService")
	private DepartmentService departmentService;
	
	private Long did;

	public Long getDid() {
		return did;
	}

	public void setDid(Long did) {
		this.did = did;
	}

	/** 列表 */
	public String list(){
		
		List<Sub> subList = null;
		Teacher teacher = (Teacher) ActionContext.getContext().getSession().get("teacher");
		subList = (List<Sub>) this.subService.getSubsByDid(teacher.getDepartment().getDid());
		ActionContext.getContext().put("subList", subList);
		return "list";
	}
	
	/** 删除 */
	public String delete() throws Exception {
		this.subService.deleteSubById(this.getModel().getSubid(), "all");
		return "toList";
	}
	
	/** 添加页面 */
	public String addUI() throws Exception {
		return "saveUI";
	}
	
	/** 添加 */
	public String add() throws Exception {
		// 保存
		Sub sub = this.getModel();
		Teacher teacher = (Teacher) ActionContext.getContext().getSession().get("teacher");
		Department department = teacher.getDepartment();
		sub.setDepartment(department);
		this.subService.saveSub(sub);
		return "toList";
	}
	
	/** 修改页面 */
	public String editUI() throws Exception {
		// 准备回显的数据
		//this.did = (Long) ActionContext.getContext().getValueStack().
/*		this.did = (Long) ServletActionContext.getRequest().getAttribute("did");*/
		Sub sub = this.subService.getSubById(this.getModel().getSubid());
		ActionContext.getContext().getValueStack().push(sub);
		return "saveUI";
	}
	
	/** 修改 */
	public String edit() throws Exception {
		// 1，从数据库取出原对象
		Sub sub = this.subService.getSubById(this.getModel().getSubid());

		// 2，设置要修改的属性
		//BeanUtils.copyProperties(this.getModel(), sub);
		sub.setSubname(this.getModel().getSubname());
		sub.setSubdesc(this.getModel().getSubdesc());

		// 3，更新到数据库中
		this.subService.updateSub(sub);
		return "toList";
	}
	
}
