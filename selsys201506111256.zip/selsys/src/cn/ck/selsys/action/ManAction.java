package cn.ck.selsys.action;

import javax.annotation.Resource;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Controller;

import cn.ck.selsys.action.base.BaseAction;
import cn.ck.selsys.domain.Man;
import cn.ck.selsys.service.ManService;
import cn.ck.selsys.utils.md5;

import com.opensymphony.xwork2.ActionContext;

@Controller("manAction")
@Scope("prototype")
public class ManAction extends BaseAction<Man>{
	@Resource(name="manService")
	private ManService manService;
	
	public String login(){
		if(ActionContext.getContext().getSession().get("student")!=null||ActionContext.getContext().getSession().get("teacher")!=null||ActionContext.getContext().getSession().get("man")!=null){
			ActionContext.getContext().put("msg", "已登录其他账号，请先退出后再操作！");
			return "loginUI";
		}
		Man m1 = this.getModel();
		Man m = manService.findByLoginNameAndPassword(m1, m1.getMid(), md5.md5(m1.getPassword()));
		//Man s = ManService.findByLoginNameAndPassword(s1, s1.getSid(),s1.getPassword());
		if(m != null){
			System.out.println("登录成功");
			ActionContext.getContext().getSession().put("man", m);
			return "tolist";
		}
		ActionContext.getContext().put("msg", "不存在此工号和密码对应的管理员！");
		return "loginUI";
	}
	
	public String editUI(){
		Man session = (Man) ActionContext.getContext().getSession().get("man");
		Man man = manService.getEntryById(session.getMid());
		ActionContext.getContext().getValueStack().push(man);
		return "editUI";
	}
	
	public String edit(){
		Man man = manService.getEntryById(this.getModel().getMid());
		man.setEmail(this.getModel().getEmail());
		man.setPhone(this.getModel().getPhone());
		man.setMname(this.getModel().getMname());
		manService.updateMan(man);
		ActionContext.getContext().getSession().remove("man");
		ActionContext.getContext().getSession().put("man", man);
		ActionContext.getContext().put("msg", "修改信息成功！ ");
		return "msg";
	}
	
	public String loginUI(){
		return "loginUI";
	}
	
	public String index() throws Exception {
		return "index";
	}

	public String top() throws Exception {
		return "top";
	}

	public String bottom() throws Exception {
		return "bottom";
	}

	public String left() throws Exception {
		return "left";
	}

	public String right() throws Exception {
		return "right";
	}
	
	/** 注销 */
	public String logout() throws Exception {
		ActionContext.getContext().getSession().remove("man");
		return "logout";
	}
	
	private String newpass;
	private String newpass1;

	public String getNewpass1() {
		return newpass1;
	}

	public void setNewpass1(String newpass1) {
		this.newpass1 = newpass1;
	}

	public String getNewpass() {
		return newpass;
	}

	public void setNewpass(String newpass) {
		this.newpass = newpass;
	}

	//转到修改密码页面
	public String editpassUI(){
		return "editpassUI";
	}
	
	public String editpass(){
		Man m1 = this.getModel();
		Man m = manService.findByLoginNameAndPassword(m1, m1.getMid(), md5.md5(m1.getPassword()));
		if(m == null){
			ActionContext.getContext().put("msg", "改密失败：原密码不对！");
			return "ErrorPage";
		}else if(getNewpass()==null||getNewpass().toString().trim().length()<1||getNewpass1()==null||getNewpass1().toString().trim().length()<1){
			ActionContext.getContext().put("msg", "改密失败：新密码不能是空字符串！");
			return "ErrorPage";
		}else if(getNewpass().equals(getNewpass1())){
			m.setPassword(md5.md5(this.getNewpass()));
			manService.updateMan(m);
			ActionContext.getContext().put("msg", "改密成功！请重新登录！");
			ActionContext.getContext().getSession().remove("man");
			return "msg";
		}else{
			ActionContext.getContext().put("msg", "改密失败：两次密码不一致！");
			return "ErrorPage";
		}
	}

}
