package cn.ck.selsys.action;

import java.util.List;

import javax.annotation.Resource;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Controller;

import cn.ck.selsys.action.base.BaseAction;
import cn.ck.selsys.domain.Department;
import cn.ck.selsys.service.DepartmentService;

import com.opensymphony.xwork2.ActionContext;

@Controller("departmentAction")
@Scope("prototype")
public class DepartmentAction extends BaseAction<Department>{
	@Resource(name="departmentService")
	private DepartmentService departmentService;
	
/*	//要修改的学院的ID
	private Long did;
	public Long getDid() {
		return did;
	}

	public void setDid(Long did) {
		this.did = did;
	}*/

	/** 列表 */
	public String list(){
		List<Department> departmentList = null;
		departmentList = (List<Department>) this.departmentService.getAllDepartment();
		ActionContext.getContext().put("departmentList", departmentList);
		return "list";
	}
	
	/** 删除 */
	public String delete() throws Exception {
		departmentService.deleteDepartmentById(this.getModel().getDid(), "all");
		return "toList";
	}
	
	/** 添加页面 */
	public String addUI() throws Exception {
		return "saveUI";
	}
	
	/** 添加 */
	public String add() throws Exception {
		// 保存
		departmentService.saveDepartment(this.getModel());
		return "toList";
	}
	
	/** 修改页面 */
	public String editUI() throws Exception {
		// 准备回显的数据
		//this.did = (Long) ActionContext.getContext().getValueStack().
/*		this.did = (Long) ServletActionContext.getRequest().getAttribute("did");*/
		Department department = departmentService.getDepartmentById(this.getModel().getDid());
		ActionContext.getContext().getValueStack().push(department);
		return "saveUI";
	}
	
	/** 修改 */
	public String edit() throws Exception {
		// 1，从数据库取出原对象
		Department department = departmentService.getDepartmentById(this.getModel().getDid());

		// 2，设置要修改的属性
		department.setDname(this.getModel().getDname());
		department.setDescription(this.getModel().getDescription());

		// 3，更新到数据库中
		departmentService.updateDepartment(department);
		return "toList";
	}
	
}
