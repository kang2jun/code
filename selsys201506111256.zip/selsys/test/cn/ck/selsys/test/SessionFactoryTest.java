package cn.ck.selsys.test;

import org.hibernate.SessionFactory;
import org.junit.Test;

public class SessionFactoryTest extends BaseSpring {
	@Test
	public void test(){
		SessionFactory sessionFactoy = (SessionFactory) context.getBean("sessionFactory");
		sessionFactoy.getCurrentSession();
	}
}
