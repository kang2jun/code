package cn.ck.selsys.test;

import java.util.ArrayList;
import java.util.List;

import org.junit.Test;

import cn.ck.selsys.domain.Student;
import cn.ck.selsys.domain.Topic;
import cn.ck.selsys.service.StudentService;
import cn.ck.selsys.utils.md5;

public class topictest extends BaseSpring{
	@Test
	public void testadd(){
		StudentService studentService = (StudentService) context.getBean("studentService");
		Student student = new Student();
		student.setSid(2L);
		student.setSname("ck");
		Topic t1 = new Topic();
		t1.setTname("topic1");
		Topic t2 = new Topic();
		t2.setTname("topic2");
		Topic t3 = new Topic();
		t3.setTname("topic3");
		ArrayList<Topic> topics = new ArrayList<Topic>();
		topics.add(0, t3);
		topics.add(t1);
		topics.add(t2);
		student.setTopics(topics);
		
		Student s2 = new Student();
		s2.setSname("haha");
		studentService.saveStudent(student);
		studentService.saveStudent(s2);
	}
	
	@Test
	public void testupdate(){
		StudentService studentService = (StudentService) context.getBean("studentService");
		Student s1 = studentService.getStudentById(20111555L);
		System.out.println(s1.getSname());
		List<Topic> topics = s1.getTopics();
		Topic t3 = topics.get(0);
		Topic t1 = topics.get(1);
		Topic t2 = topics.get(2);
		topics.clear();
		topics.add(t1);
		topics.add(t2);
		topics.add(t3);
		s1.setTopics(topics);
		studentService.updateStudent(s1);
	}
	
	@Test
	public void testdelete(){
		StudentService studentService = (StudentService) context.getBean("studentService");
		studentService.deleteStudentById(1L, "hha");
	}
	
	@Test
	public void md5Test(){
		String res = md5.md5("123");
		System.out.println(res);
	}

	
	

}
