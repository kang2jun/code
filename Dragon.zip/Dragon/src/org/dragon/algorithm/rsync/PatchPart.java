package org.dragon.algorithm.rsync;

import java.io.Serializable;

/**
 * 补丁块
 * @author: 0xC000005
 * @mailto: flexie@foxmail.com
 * @date: 2014年7月14日
 * @Blog : http://0xC000005.github.io/
 */
public abstract class PatchPart implements Serializable{
	private static final long serialVersionUID = 1L;
}
