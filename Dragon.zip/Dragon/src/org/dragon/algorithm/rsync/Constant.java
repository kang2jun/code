package org.dragon.algorithm.rsync;
/**
 * 定义算法的常量
 * @author: 0xC000005
 * @mailto: flexie@foxmail.com
 * @date: 2014年7月12日
 * @Blog : http://0xC000005.github.io/
 */
public class Constant {
	//分块大小
	public static final int CHUNK_SIZE=1024*1024;
}
