package org.dragon.algorithm.rsync;
/**
 * 特殊的补丁块，里面存放的是与服务器不一致的数据.
 * @author: 0xC000005
 * @mailto: flexie@foxmail.com
 * @date: 2014年7月14日
 * @Blog : http://0xC000005.github.io/
 */
public class PatchPartData extends PatchPart{
	private static final long serialVersionUID = 1L;
	private byte[] datas;
	private int length;
	public byte[] getDatas() {
		return datas;
	}
	public void setDatas(byte[] datas) {
		this.datas = datas;
	}
	public int getLength() {
		return length;
	}
	public void setLength(int length) {
		this.length = length;
	}
}
