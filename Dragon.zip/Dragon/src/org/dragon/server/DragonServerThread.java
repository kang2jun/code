package org.dragon.server;

import java.io.File;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.BlockingQueue;

import org.dragon.algorithm.MD5;
import org.dragon.algorithm.rsync.Chunk;
import org.dragon.algorithm.rsync.Patch;
import org.dragon.algorithm.rsync.Rsync;
import org.dragon.biz.AccountService;
import org.dragon.biz.impl.FileAccountServiceImpl;
import org.dragon.constant.DragonMessageType;
import org.dragon.entity.Account;
import org.dragon.entity.DragonMessage;
import org.dragon.hadoop.HadoopTask;
import org.dragon.util.threadpool.Task;

/**
 * 服务器线程
 * @author: 0xC000005
 * @mailto: flexie@foxmail.com
 * @date: 2014年7月16日
 * @Blog : http://0xC000005.github.io/
 */
public class DragonServerThread extends Thread{
	private ObjectInputStream ois;
	private ObjectOutputStream oos;
	private AccountService  acctService = new FileAccountServiceImpl();
	private Map<String,Long> matchDatas = new HashMap<String,Long>();
	private boolean flag = true;
	private static String filePath="F:\\remote\\";
	private Thread thread;
	private BlockingQueue<Task> queue;
	public DragonServerThread( Socket socket , BlockingQueue<Task> queue) {
		try {
			ois = new ObjectInputStream(socket.getInputStream());
			oos = new ObjectOutputStream(socket.getOutputStream());
			this.queue = queue;
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	@Override
	public void run(){
		while(flag){
			try {
				DragonMessage msg = (DragonMessage) ois.readObject();
				switch(msg.getMsgType()){
					case DragonMessageType.ACCOUNT_CREATE:
						createAccount(msg.getAcct());
						break;
					case DragonMessageType.ACCOUNT_LOGIN:
						loginAccount(msg.getAcct());
						break;
					case DragonMessageType.ACCOUNT_LOGOUT:
						loginout(msg.getAcct());
						flag =false;
						break;
					case DragonMessageType.RSYNC_CHECKSUM:
						calcCheckSum(msg);
						break;
					case DragonMessageType.RSYNC_PATCH:
						applyPatch(msg);
						break;
					case DragonMessageType.RSYNC_DIR: //创建目录
						createDir(msg);
						break;
					default:
						break;
				}
			} catch (Exception e) {
				e.printStackTrace();
				thread.interrupt();
				break;
			}
		}
	}
	
	private void createDir(DragonMessage msg) throws IOException {
		String clientFilePath = msg.getFileName();
		File file  = new File(filePath+msg.getAcct().getName()+clientFilePath);
		if( !file.exists() ){
			file.mkdirs();
		}
		matchDatas.put(msg.getSourceFileName(),msg.getFileLength());
		DragonMessage msg02 = new DragonMessage();
		msg02.setMsgType(DragonMessageType.SUCCESS);
		msg02.setContent("文件同步成功 !");
		oos.writeObject(msg02);
	}
	private void applyPatch(DragonMessage msg) throws Exception {
		String clientFilePath = msg.getFileName();
		Patch patch = msg.getPatch();
		System.out.println(filePath+msg.getAcct().getName()+clientFilePath);
		File file  = new File(filePath+msg.getAcct().getName()+clientFilePath);
		if(!file.exists()){
			File parent = file.getParentFile();
			if(!parent.exists()){
				parent.mkdirs();
			}
			file.createNewFile();
		}
		Rsync.createNewFile(patch, filePath+msg.getAcct().getName()+clientFilePath);
		//生成一个HadoopTask ,放进队列中,让线程池去从队列中获取任务并处理.
		Task task = new HadoopTask(
					filePath+msg.getAcct().getName()+clientFilePath ,
					"/hadoop/"+msg.getAcct().getName()+clientFilePath);
		queue.offer(task);
		matchDatas.put(msg.getSourceFileName(),msg.getFileLength());
		DragonMessage msg02 = new DragonMessage();
		msg02.setMsgType(DragonMessageType.SUCCESS);
		msg02.setContent("文件同步成功 !");
		oos.writeObject(msg02);
	}
	private void calcCheckSum(DragonMessage msg) throws Exception {
		String clientFilePath = msg.getFileName();
		Map<Integer,List<Chunk>> checkSums = Rsync.calcCheckSum(filePath+clientFilePath);
		if(checkSums ==null){
			checkSums= new HashMap<Integer,List<Chunk>>();
		}
		DragonMessage msg02 = new DragonMessage();
		msg02.setMsgType(DragonMessageType.RSYNC_CHECKSUM);
		msg02.setCheckSums(checkSums);
		oos.writeObject(msg02);
	}
	private void loginAccount(Account acct) throws IOException {
		System.out.println("[Server] 用户登录");
		Account temp  =  acctService.queryAccountByName(acct.getName());
		if(temp == null){
			DragonMessage msg = new DragonMessage();
			msg.setMsgType(DragonMessageType.ERROR);
			msg.setContent("此账户不存在 !");
			oos.writeObject(msg);
			return;
		}
		if(temp.getPassword().equals(MD5.getMD5(acct.getPassword().getBytes()))){
			DragonServerMatchFileUtil matchUtil = new DragonServerMatchFileUtil(filePath+acct.getName()+"\\match.dat");
			try {
				matchDatas = matchUtil.parseMatchFile();
				//启动一个定时刷新匹配文件到硬盘的线程
				thread = new DragonServerSaveThread(acct, filePath, matchDatas);
				thread.start();
			} catch (Exception e) {
				e.printStackTrace();
			}
			DragonMessage msg = new DragonMessage();
			msg.setMsgType(DragonMessageType.SUCCESS);
			msg.setMatchFile(matchDatas);
			msg.setContent("服务器校验通过 !");
			oos.writeObject(msg);
		}else{
			DragonMessage msg = new DragonMessage();
			msg.setMsgType(DragonMessageType.ERROR);
			msg.setContent("服务器校验失败 !");
			oos.writeObject(msg);
		}
	}
	private void createAccount(Account acct) throws IOException {
		System.out.println("[Server] 用户注册");
		Account temp  =  acctService.queryAccountByName(acct.getName());
		if( temp !=null ){ //如果查询到该用户名的账户，失败.
			DragonMessage msg = new DragonMessage();
			msg.setMsgType(DragonMessageType.ERROR);
			msg.setContent("服务器已存在该用户 !");
			oos.writeObject(msg);
		}else{
			DragonMessage msg = new DragonMessage();
			msg.setMsgType(DragonMessageType.SUCCESS);
			msg.setContent("成功注册改用户  !");
			oos.writeObject(msg);
			acct.setPassword(MD5.getMD5(acct.getPassword().getBytes()));
			acctService.addAccount(acct);
		}
	}
	
	private void loginout(Account acct) throws IOException {
		DragonMessage msg = new DragonMessage();
		msg.setMsgType(DragonMessageType.SUCCESS);
		msg.setContent("成功退出  !");
		DragonServerMatchFileUtil matchUtil = new DragonServerMatchFileUtil(filePath+acct.getName()+"\\match.dat");
		try {
			matchUtil.saveMatchFile(matchDatas);
		} catch (Exception e) {
			e.printStackTrace();
		}
		oos.writeObject(msg);
	}	
}
