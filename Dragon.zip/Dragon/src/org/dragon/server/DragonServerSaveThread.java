package org.dragon.server;

import java.util.HashMap;
import java.util.Map;

import org.dragon.entity.Account;

/**
 * @author: 0xC000005
 * @mailto: flexie@foxmail.com
 * @date: 2014年7月17日
 * @Blog : http://0xC000005.github.io/
 */
public class DragonServerSaveThread extends Thread{
	
	private Map<String,Long> matchDatas = new HashMap<String,Long>();
	private String filePath ;
	private Account acct;
	public DragonServerSaveThread(Account acct , String filePath , Map<String,Long> matchDatas) {
		this.matchDatas = matchDatas;
		this.filePath = filePath;
		this.acct = acct;
	}
	@Override
	public void run(){
		while(true){
			System.out.println(filePath+acct.getName()+"\\match.dat");
			DragonServerMatchFileUtil matchUtil = new DragonServerMatchFileUtil(filePath+acct.getName()+"\\match.dat");
			try {
				System.out.println("刷新匹配文件到硬盘 !");
				matchUtil.saveMatchFile(matchDatas);
			} catch (Exception e) {
				e.printStackTrace();
			}
			try {
				Thread.sleep(30*1000);
			} catch (InterruptedException e) {
				e.printStackTrace();
				break;
			}
		}
	}
}
