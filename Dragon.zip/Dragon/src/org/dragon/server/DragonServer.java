package org.dragon.server;

import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.LinkedBlockingQueue;

import org.dragon.util.threadpool.SimpleThreadPool;
import org.dragon.util.threadpool.Task;

/**
 * 服务器
 * @author: 0xC000005
 * @mailto: flexie@foxmail.com
 * @date: 2014年7月16日
 * @Blog : http://0xC000005.github.io/
 */
public class DragonServer {
	private static boolean flag = true;
	private static BlockingQueue<Task> queue = new LinkedBlockingQueue<Task>();
	public  static void main(String[] args) {
		ServerSocket  server = null;
		try {
			 server = new ServerSocket(9527);
		} catch (IOException e) {
			e.printStackTrace();
		}
		System.out.println("启动服务器成功 !");
		//启动线程池
		SimpleThreadPool pool = new SimpleThreadPool(queue,5);
		pool.start();
		System.out.println("启动线程池成功 !");
		while(flag){
			try {
				Socket socket = server.accept();
				System.out.println("客户机["+socket.getRemoteSocketAddress()+"] 成功连接 !");
				new DragonServerThread(socket ,queue).start();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
	}
}
