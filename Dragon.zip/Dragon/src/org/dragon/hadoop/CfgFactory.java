package org.dragon.hadoop;

import org.apache.hadoop.conf.Configuration;
/**
 * 工厂类
 * @author: 0xC000005
 * @mailto: flexie@foxmail.com
 * @date: 2014年7月19日
 * @Blog : http://0xC000005.github.io/
 */
public class CfgFactory {
	private static Configuration conf;
	public static Configuration createConf(){
		if( conf ==null ){
				conf = new Configuration();
				conf.addResource(CfgFactory.class.getResourceAsStream("core-site.xml"));
		}
		return conf;
	}
}
