package org.dragon.hadoop;

import org.dragon.util.threadpool.Task;

/**
 * 上传文件到Hadoop的任务
 * @author: 0xC000005
 * @mailto: flexie@foxmail.com
 * @date: 2014年7月19日
 * @Blog : http://0xC000005.github.io/
 */
public class HadoopTask implements Task{
	private String src; //在server中的路径
	private String dst;//在hadoop中的路径
	public HadoopTask(String src , String dst){
		this.src = src;
		this.dst = dst;
	}
	@Override
	public void run() {
		try {
			HadoopUtils.addFile(src, dst);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
