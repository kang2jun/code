package org.dragon.hadoop;


import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.FileStatus;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.Path;

/**
 * Hadoop 工具类
 * @author: 0xC000005
 * @mailto: flexie@foxmail.com
 * @date: 2014年7月19日
 * @Blog : http://0xC000005.github.io/
 */
public class HadoopUtils {
		/**
		 * 遍历文件
		 * @param fileName
		 * @throws Exception
		 */
		public static void listFile(String fileName) throws Exception{
			//1.获取配置文件
			Configuration conf = CfgFactory.createConf();
			//2.Hadoop文件系统
			FileSystem fs = FileSystem.newInstance(conf);
			//3.获取Path下的文件和目录
			FileStatus[] files = fs.listStatus(new Path(fileName));
			if(files !=null){
				for( FileStatus file : files){
					System.out.println(file.getPath());
				}
			}
		}
		
		/**
		 * 向HDFS增加文件
		 * @param src
		 * @param dst
		 * @throws Exception
		 */
		public static void addFile(String src , String dst) throws Exception{
			System.out.println("[Hadoop] add "+src+" --> "+dst);
			Configuration conf = CfgFactory.createConf();
			FileSystem fs = FileSystem.newInstance(conf);
			fs.copyFromLocalFile(new Path(src),new Path(dst));
		}
		
		public static void delFile(String filePath) throws Exception{
			Configuration conf = CfgFactory.createConf();
			FileSystem fs = FileSystem.newInstance(conf);
			fs.delete(new Path(filePath),true);
		}
		
}
