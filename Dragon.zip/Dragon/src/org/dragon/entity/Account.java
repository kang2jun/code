package org.dragon.entity;

import java.io.Serializable;

/**
 * 账户类
 * @author: 0xC000005
 * @mailto: flexie@foxmail.com
 * @date: 2014年7月16日
 * @Blog : http://0xC000005.github.io/
 */
public class Account implements Serializable{
	private static final long serialVersionUID = 1L;
	private String name;
	private String password;
	
	public Account(){}
	public Account(String name ,String password){
		this.name = name;
		this.password = password;
	}
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
}
