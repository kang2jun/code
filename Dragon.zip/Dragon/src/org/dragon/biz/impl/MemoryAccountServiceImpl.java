package org.dragon.biz.impl;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import org.dragon.biz.AccountService;
import org.dragon.entity.Account;

/**
 * 基于内存的用户管理
 * @author: 0xC000005
 * @mailto: flexie@foxmail.com
 * @date: 2014年7月16日
 * @Blog : http://0xC000005.github.io/
 */
public class MemoryAccountServiceImpl implements AccountService{
	private static Map<String,Account> accts = 
			new ConcurrentHashMap<String,Account>();
	@Override
	public boolean addAccount(Account acct) {
		accts.put(acct.getName(), acct);
		return true;
	}

	@Override
	public Account queryAccountByName(String name) {
		return accts.get(name);
	}

}
