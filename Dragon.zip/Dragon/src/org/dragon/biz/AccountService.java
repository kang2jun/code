package org.dragon.biz;

import org.dragon.entity.Account;

/**
 * 用户的管理接口
 * @author: 0xC000005
 * @mailto: flexie@foxmail.com
 * @date: 2014年7月16日
 * @Blog : http://0xC000005.github.io/
 */
public interface AccountService {
	
	public boolean addAccount(Account acct);
	public Account  queryAccountByName(String name);
}
