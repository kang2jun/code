package org.dragon.util.threadpool;
/**
 * 任务
 * @author: 0xC000005
 * @mailto: flexie@foxmail.com
 * @date: 2014年7月15日
 * @Blog : http://0xC000005.github.io/
 */
public interface Task {
		//任务
		public void run();
}
