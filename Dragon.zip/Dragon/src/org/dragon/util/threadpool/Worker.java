package org.dragon.util.threadpool;

import java.util.concurrent.BlockingQueue;

/**
 * 工人类，任务的具体执行者.
 * @author: 0xC000005
 * @mailto: flexie@foxmail.com
 * @date: 2014年7月15日
 * @Blog : http://0xC000005.github.io/
 */
public class Worker extends Thread{
	private boolean flag = true;
	private BlockingQueue<Task> tasks; //任务队列
	public Worker(String name , BlockingQueue<Task> tasks){
		super(name);
		this.tasks = tasks;
	}
	@Override
	public void run(){
		while(flag){ //工人非常勤劳，24小时不下班，资本家的最爱.
			try {
				Task task = tasks.take(); //拿到任务就执行.
				task.run(); 
				System.out.println(Thread.currentThread().getName()+" 执行任务完毕 !");
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
	}
	public boolean isFlag() {
		return flag;
	}
	public void setFlag(boolean flag) {
		this.flag = flag;
	}
	
}
