package org.dragon.algorithm.test;

import java.io.File;
import java.util.List;
import java.util.Map;

import org.dragon.algorithm.rsync.Chunk;
import org.dragon.algorithm.rsync.Patch;
import org.dragon.algorithm.rsync.Rsync;

/**
 * 测试Rsync算法
 * @author: 0xC000005
 * @mailto: flexie@foxmail.com
 * @date: 2014年7月14日
 * @Blog : http://0xC000005.github.io/
 */
public class TestRsync {
	public static void main(String[] args) throws Exception {
		long start = System.currentTimeMillis();
		//1. 算出校验和
		Map<Integer,List<Chunk>> checkSums = Rsync.calcCheckSum("H:\\local\\GeminiV2\\jpathwatch-0-95.jar");
	
		//2. 生成补丁
		File file = new File("H:\\local\\GeminiV2\\jpathwatch-0-95.jar");
		Patch patch = Rsync.createPatch(checkSums, "H:\\local\\GeminiV2\\jpathwatch-0-95.jar",0,file.length());
			
		//3. 生成新的文件
		Rsync.createNewFile(patch, "F:\\remote\\test.iso");
		long end = System.currentTimeMillis();
		
		System.out.println("运行时间为 :"+(end-start));
	
	}
}
