package org.dragon.algorithm.test;

import java.io.File;

import org.apache.commons.io.FileUtils;

/**
 * 测试文件大小
 * @author: 0xC000005
 * @mailto: flexie@foxmail.com
 * @date: 2014年7月17日
 * @Blog : http://0xC000005.github.io/
 */
public class TestFileLength {

	public static void main(String[] args) {
		File file = new File("H:\\local");
		System.out.println(FileUtils.sizeOf(file));

	}

}
